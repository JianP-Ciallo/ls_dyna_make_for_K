*SECTION_SOLID
9700002,11
*PART
AIR_mm_background
9300288,9700002,9008,1
*PART
TNT_cylinder_example_deferred_initiation
9300290,9700002,9009,2
*PART
VACUUM_ground_coupling_buffer
9300289,9700002,9010,0
*MAT_NULL+
$#     mid        ro        pc        mu     terod     cerod        ym        pr
9008,1.225,0,0,0,0,0,0
*EOS_LINEAR_POLYNOMIAL
$#   eosid        c0        c1        c2        c3        c4        c5        c6
1,0,0,0,0,0.4,0.4,0
$#      e0        v0
253312.5,1
$ Existing reference preset; BETA=2 selects programmed burn only.
*MAT_HIGH_EXPLOSIVE_BURN
9009,1630,6930,2.1e+10,2
*EOS_JWL
2,3.712e+11,3.231e+09,4.15,0.95,0.3,7e+09,1
*ALE_MULTI-MATERIAL_GROUP
9300288,1
9300290,1
9300289,1
*MAT_VACUUM
9010,1e-9
