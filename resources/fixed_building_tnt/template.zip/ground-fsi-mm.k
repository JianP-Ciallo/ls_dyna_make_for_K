*SET_PART_LIST_TITLE
ground_fsi_mm_air_tnt_vacuum_mesh
9500574
9300288,9300290,9300289
*SET_MULTI-MATERIAL_GROUP_LIST_TITLE
ground_fsi_real_fluids_excluding_vacuum
9500576
1,2
*CONTROL_ALE
$#     dct      nadv      meth      afac      bfac      cfac      dfac      efac
-1,1,2,-1.0,0.0,0.0,0.0,0.0
$#   start       end     aafac     vfact    vlimit       ebc      pref   nsidebc
0.0,1.0e20,1.0,1.0e-6,0,0,101325.0,0
*CONSTRAINED_LAGRANGE_IN_SOLID
9300287,9500574,1,0,2,5,2,-9500576
0,1e20,0.1,0,0.5,0,0,0
0,0,0,0,0,0,0,0
