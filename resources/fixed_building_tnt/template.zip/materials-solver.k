$ Canonical residential SI references: NOT calibrated engineering failure predictions
*MAT_CONCRETE_DAMAGE_REL3_TITLE+
concrete_uncalibrated_reference
9002,2400,0.2
,-30000000,,,,,
,2,,39.37,0.00014503773773,9600001,,
,,,,,,,
,,,,,,,
,,,,,,,
,,,,,,,
$ numerical_element_deletion_only; uncalibrated_internal_reference
*MAT_ADD_EROSION
9002,0,0,0,0,0,1,1
0,0,0,0.05,0,0,0,0
*MAT_ELASTIC_TITLE+
door_leaf_uncalibrated_reference
9006,600,5000000000,0.25
$ numerical_element_deletion_only; uncalibrated_internal_reference
*MAT_ADD_EROSION
9006,0,0,0,0,0,1,1
0,0,0,0.02,0,0,0,0
*MAT_PLASTIC_KINEMATIC_TITLE+
frame_uncalibrated_reference
9005,7850,210000000000,0.3,210000000,1000000000,0
0,0,0.15,0
*MAT_ELASTIC_TITLE+
glazing_uncalibrated_reference
9004,2500,70000000000,0.22
$ numerical_element_deletion_only; uncalibrated_internal_reference
*MAT_ADD_EROSION
9004,0,0,0,0,0,1,1
0,45000000,0,0,0,0,0,0
*MAT_ELASTIC_TITLE+
partition_uncalibrated_reference
9003,1800,5000000000,0.2
$ numerical_element_deletion_only; uncalibrated_internal_reference
*MAT_ADD_EROSION
9003,0,0,-0.001,0,0,1,1
0,300000,0,0,0,0,0,0
*MAT_PLASTIC_KINEMATIC_TITLE+
reinforcing_steel_uncalibrated_reference
9001,7850,210000000000,0.3,400000000,1000000000,0
0,0,0.15,0
*MAT_PLASTIC_KINEMATIC_TITLE+
steel_uncalibrated_reference
9007,7850,210000000000,0.3,210000000,1000000000,0
0,0,0.15,0
*DEFINE_CURVE_TITLE
concrete_rate_multiplier_disabled_reference
9600001,0,1,1,0,0,0,0
-1000000,1
1000000,1
