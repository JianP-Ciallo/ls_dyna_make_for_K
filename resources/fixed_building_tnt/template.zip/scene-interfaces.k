*CONSTRAINED_LAGRANGE_IN_SOLID
9600002,9500574,0,0,2,5,2,-9500576
0,1e20,0.1,0,0.5,0,0,0
0,0,0,0,0,0,0,0
$ Initially coincident foundation/ground ideal bond, penalty OFFSET, no projection.
*CONTACT_TIED_NODES_TO_SURFACE_OFFSET_ID
9600013,foundation_ground_initial_bond
9600009,9600010,4,0,0,0,0,0
0,0,0,0,0,0,0,1e20
1,1,-1e-6,-1e-6,0,0,1,1
