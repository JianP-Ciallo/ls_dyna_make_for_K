$ retained fixture
