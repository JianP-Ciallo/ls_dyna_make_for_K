$ repaired reference retained verbatim
