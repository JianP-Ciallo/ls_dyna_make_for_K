$ Actual architecture installation reference; ideal nonfailing connections
$ Mesh digest: bf73c720855513dba3450f0aa5042336ad4712ec83ad0de4f9176e3be914ba01
$ Include requires the unchanged original Solid mesh; full solver deck pending
*NODE
$ Auxiliary hinge axis nodes; original nodes are not repeated
  439233           3.295            0.12           0.175
  439234           3.295            0.12           0.175
  439235           3.295            0.12           0.225
  439236           3.295            0.12           0.225
  439237           3.295            0.12           1.985
  439238           3.295            0.12           1.985
  439239           3.295            0.12           2.035
  439240           3.295            0.12           2.035
  439241           5.615            0.12           0.175
  439242           5.615            0.12           0.175
  439243           5.615            0.12           0.225
  439244           5.615            0.12           0.225
  439245           5.615            0.12           1.985
  439246           5.615            0.12           1.985
  439247           5.615            0.12           2.035
  439248           5.615            0.12           2.035
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800001     22531       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236740       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800002     22534       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236742       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800003     22535       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236742       123.894736842.894736842.894736842.894736842.894736842.894736842
    236768       123.105263158.105263158.105263158.105263158.105263158.105263158
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800004     22532       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236740       123.894736842.894736842.894736842.894736842.894736842.894736842
    236766       123.105263158.105263158.105263158.105263158.105263158.105263158
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800005     22536       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236742       123.789473684.789473684.789473684.789473684.789473684.789473684
    236768       123.210526316.210526316.210526316.210526316.210526316.210526316
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800006     22533       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236740       123.789473684.789473684.789473684.789473684.789473684.789473684
    236766       123.210526316.210526316.210526316.210526316.210526316.210526316
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800007     22540       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238497       123.909090909.909090909.909090909.909090909.909090909.909090909
    238499       123.090909091.090909091.090909091.090909091.090909091.090909091
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800008     22543       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238498       123.909090909.909090909.909090909.909090909.909090909.909090909
    238500       123.090909091.090909091.090909091.090909091.090909091.090909091
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800009     22561       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238502       123.727272727.727272727.727272727.727272727.727272727.727272727
    238504       123.272727273.272727273.272727273.272727273.272727273.272727273
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800010     22558       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238501       123.727272727.727272727.727272727.727272727.727272727.727272727
    238503       123.272727273.272727273.272727273.272727273.272727273.272727273
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800011     22567       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238503       123.636363636.636363636.636363636.636363636.636363636.636363636
    238505       123.363636364.363636364.363636364.363636364.363636364.363636364
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800012     22570       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238504       123.636363636.636363636.636363636.636363636.636363636.636363636
    238506       123.363636364.363636364.363636364.363636364.363636364.363636364
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800013     22588       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238508       123.454545455.454545455.454545455.454545455.454545455.454545455
    238510       123.545454545.545454545.545454545.545454545.545454545.545454545
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800014     22585       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238507       123.454545455.454545455.454545455.454545455.454545455.454545455
    238509       123.545454545.545454545.545454545.545454545.545454545.545454545
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800015     22594       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238509       123.363636364.363636364.363636364.363636364.363636364.363636364
    238511       123.636363636.636363636.636363636.636363636.636363636.636363636
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800016     22597       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238510       123.363636364.363636364.363636364.363636364.363636364.363636364
    238512       123.636363636.636363636.636363636.636363636.636363636.636363636
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800017     22537       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238525       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800018     22546       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238526       123.909090909.909090909.909090909.909090909.909090909.909090909
    238527       123.090909091.090909091.090909091.090909091.090909091.090909091
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800019     22564       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238528       123.727272727.727272727.727272727.727272727.727272727.727272727
    238529       123.272727273.272727273.272727273.272727273.272727273.272727273
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800020     22573       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238529       123.636363636.636363636.636363636.636363636.636363636.636363636
    238530       123.363636364.363636364.363636364.363636364.363636364.363636364
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800021     22591       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238531       123.454545455.454545455.454545455.454545455.454545455.454545455
    238532       123.545454545.545454545.545454545.545454545.545454545.545454545
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800022     22600       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238532       123.363636364.363636364.363636364.363636364.363636364.363636364
    238533       123.636363636.636363636.636363636.636363636.636363636.636363636
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800023     22609       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238533       123.272727273.272727273.272727273.272727273.272727273.272727273
    238534       123.727272727.727272727.727272727.727272727.727272727.727272727
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800024     22606       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238512       123.272727273.272727273.272727273.272727273.272727273.272727273
    238514       123.727272727.727272727.727272727.727272727.727272727.727272727
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800025     22615       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238514       123.181818182.181818182.181818182.181818182.181818182.181818182
    238516       123.818181818.818181818.818181818.818181818.818181818.818181818
$ F0.shaft_front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800026     22618       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238534       123.181818182.181818182.181818182.181818182.181818182.181818182
    238535       123.818181818.818181818.818181818.818181818.818181818.818181818
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800027     22621       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236844       123.210526316.210526316.210526316.210526316.210526316.210526316
    236870       123.789473684.789473684.789473684.789473684.789473684.789473684
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800028     22624       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236846       123.210526316.210526316.210526316.210526316.210526316.210526316
    236872       123.789473684.789473684.789473684.789473684.789473684.789473684
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800029     22625       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236846       123.105263158.105263158.105263158.105263158.105263158.105263158
    236872       123.894736842.894736842.894736842.894736842.894736842.894736842
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800030     22622       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236844       123.105263158.105263158.105263158.105263158.105263158.105263158
    236870       123.894736842.894736842.894736842.894736842.894736842.894736842
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800031     22626       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236872       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800032     22623       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236870       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800033     22635       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238960       123.909090909.909090909.909090909.909090909.909090909.909090909
    238964       123.090909091.090909091.090909091.090909091.090909091.090909091
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800034     22632       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238957       123.909090909.909090909.909090909.909090909.909090909.909090909
    238961       123.090909091.090909091.090909091.090909091.090909091.090909091
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800035     22650       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238965       123.727272727.727272727.727272727.727272727.727272727.727272727
    238969       123.272727273.272727273.272727273.272727273.272727273.272727273
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800036     22653       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238968       123.727272727.727272727.727272727.727272727.727272727.727272727
    238972       123.272727273.272727273.272727273.272727273.272727273.272727273
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800037     22662       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238972       123.636363636.636363636.636363636.636363636.636363636.636363636
    238976       123.363636364.363636364.363636364.363636364.363636364.363636364
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800038     22659       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238969       123.636363636.636363636.636363636.636363636.636363636.636363636
    238973       123.363636364.363636364.363636364.363636364.363636364.363636364
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800039     22677       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238977       123.454545455.454545455.454545455.454545455.454545455.454545455
    238981       123.545454545.545454545.545454545.545454545.545454545.545454545
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800040     22680       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238980       123.454545455.454545455.454545455.454545455.454545455.454545455
    238984       123.545454545.545454545.545454545.545454545.545454545.545454545
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800041     22689       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238984       123.363636364.363636364.363636364.363636364.363636364.363636364
    238988       123.636363636.636363636.636363636.636363636.636363636.636363636
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800042     22686       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238981       123.363636364.363636364.363636364.363636364.363636364.363636364
    238985       123.636363636.636363636.636363636.636363636.636363636.636363636
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800043     22629       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    239004       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800044     22638       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    239006       123.909090909.909090909.909090909.909090909.909090909.909090909
    239008       123.090909091.090909091.090909091.090909091.090909091.090909091
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800045     22665       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    239012       123.636363636.636363636.636363636.636363636.636363636.636363636
    239014       123.363636364.363636364.363636364.363636364.363636364.363636364
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800046     22674       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    239014       123.545454545.545454545.545454545.545454545.545454545.545454545
    239016       123.454545455.454545455.454545455.454545455.454545455.454545455
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800047     22671       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238976       123.545454545.545454545.545454545.545454545.545454545.545454545
    238980       123.454545455.454545455.454545455.454545455.454545455.454545455
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800048     22692       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    239018       123.363636364.363636364.363636364.363636364.363636364.363636364
    239020       123.636363636.636363636.636363636.636363636.636363636.636363636
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800049     22701       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    239020       123.272727273.272727273.272727273.272727273.272727273.272727273
    239022       123.727272727.727272727.727272727.727272727.727272727.727272727
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800050     22698       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238988       123.272727273.272727273.272727273.272727273.272727273.272727273
    238992       123.727272727.727272727.727272727.727272727.727272727.727272727
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800051     22710       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238895       123.818181818.818181818.818181818.818181818.818181818.818181818
    239022       123.181818182.181818182.181818182.181818182.181818182.181818182
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800052     22707       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238886       123.818181818.818181818.818181818.818181818.818181818.818181818
    238992       123.181818182.181818182.181818182.181818182.181818182.181818182
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800053     22644       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238964       123.818181818.818181818.818181818.818181818.818181818.818181818
    238968       123.181818182.181818182.181818182.181818182.181818182.181818182
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800054     22641       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238961       123.818181818.818181818.818181818.818181818.818181818.818181818
    238965       123.181818182.181818182.181818182.181818182.181818182.181818182
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800055     22647       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    239008       123.818181818.818181818.818181818.818181818.818181818.818181818
    239010       123.181818182.181818182.181818182.181818182.181818182.181818182
$ F0.shaft_front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800056     22656       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    239010       123.727272727.727272727.727272727.727272727.727272727.727272727
    239012       123.272727273.272727273.272727273.272727273.272727273.272727273
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800057     22491       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238514       123.181818182.181818182.181818182.181818182.181818182.181818182
    238516       123.818181818.818181818.818181818.818181818.818181818.818181818
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800058     22486       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238513       123.181818182.181818182.181818182.181818182.181818182.181818182
    238515       123.818181818.818181818.818181818.818181818.818181818.818181818
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800059     22501       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238513       123.090909091.090909091.090909091.090909091.090909091.090909091
    238515       123.909090909.909090909.909090909.909090909.909090909.909090909
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800060     22506       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238514       123.090909091.090909091.090909091.090909091.090909091.090909091
    238516       123.909090909.909090909.909090909.909090909.909090909.909090909
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800061     22511       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238534       123.090909091.090909091.090909091.090909091.090909091.090909091
    238535       123.909090909.909090909.909090909.909090909.909090909.909090909
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800062     22521       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238516       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800063     22526       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238535       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800064     22490       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238885       123.818181818.818181818.818181818.818181818.818181818.818181818
    238989       123.181818182.181818182.181818182.181818182.181818182.181818182
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800065     22495       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238886       123.818181818.818181818.818181818.818181818.818181818.818181818
    238992       123.181818182.181818182.181818182.181818182.181818182.181818182
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800066     22510       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238886       123.909090909.909090909.909090909.909090909.909090909.909090909
    238992       123.090909091.090909091.090909091.090909091.090909091.090909091
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800067     22505       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238885       123.909090909.909090909.909090909.909090909.909090909.909090909
    238989       123.090909091.090909091.090909091.090909091.090909091.090909091
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800068     22515       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238895       123.909090909.909090909.909090909.909090909.909090909.909090909
    239022       123.090909091.090909091.090909091.090909091.090909091.090909091
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800069     22530       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238895       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800070     22525       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238886       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800071     22516       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238515       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800072     22517       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238597       123.684210526.684210526.684210526.684210526.684210526.684210526
    238669       123.315789474.315789474.315789474.315789474.315789474.315789474
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800073     22522       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238598       123.684210526.684210526.684210526.684210526.684210526.684210526
    238670       123.315789474.315789474.315789474.315789474.315789474.315789474
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800074     22519       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238741       123.315789474.315789474.315789474.315789474.315789474.315789474
    238813       123.684210526.684210526.684210526.684210526.684210526.684210526
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800075     22520       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238885       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800076     22524       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238742       123.315789474.315789474.315789474.315789474.315789474.315789474
    238814       123.684210526.684210526.684210526.684210526.684210526.684210526
$ F0.shaft_front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800077     22529       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238751       123.315789474.315789474.315789474.315789474.315789474.315789474
    238823       123.684210526.684210526.684210526.684210526.684210526.684210526
$ F0.shaft_front.opening0.frame.top frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800078     22496       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238534       123.181818182.181818182.181818182.181818182.181818182.181818182
    238535       123.818181818.818181818.818181818.818181818.818181818.818181818
$ F0.shaft_front.opening0.frame.top frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800079     22500       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    238895       123.818181818.818181818.818181818.818181818.818181818.818181818
    239022       123.181818182.181818182.181818182.181818182.181818182.181818182
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800080     22716       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236742       123.789473684.789473684.789473684.789473684.789473684.789473684
    236768       123.210526316.210526316.210526316.210526316.210526316.210526316
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800081     22711       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236740       123.157894737.157894737.157894737.157894737.157894737.157894737
    236742       123.631578947.631578947.631578947.631578947.631578947.631578947
    236766       123.042105263.042105263.042105263.042105263.042105263.042105263
    236768       123.168421053.168421053.168421053.168421053.168421053.168421053
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800082     22726       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22542       123        .2        .2        .2        .2        .2        .2
     22545       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800083     22731       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22545       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800084     22715       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236844       123.042105263.042105263.042105263.042105263.042105263.042105263
    236846       123.168421053.168421053.168421053.168421053.168421053.168421053
    236870       123.157894737.157894737.157894737.157894737.157894737.157894737
    236872       123.631578947.631578947.631578947.631578947.631578947.631578947
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800085     22720       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    236846       123.210526316.210526316.210526316.210526316.210526316.210526316
    236872       123.789473684.789473684.789473684.789473684.789473684.789473684
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800086     22735       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22633       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800087     22730       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22630       123        .2        .2        .2        .2        .2        .2
     22633       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800088     22721       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22539       123        .2        .2        .2        .2        .2        .2
    236742       123.631578947.631578947.631578947.631578947.631578947.631578947
    236768       123.168421053.168421053.168421053.168421053.168421053.168421053
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800089     22736       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22545       123        .8        .8        .8        .8        .8        .8
     22548       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800090     22725       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22627       123        .2        .2        .2        .2        .2        .2
    236846       123.168421053.168421053.168421053.168421053.168421053.168421053
    236872       123.631578947.631578947.631578947.631578947.631578947.631578947
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800091     22740       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22633       123        .8        .8        .8        .8        .8        .8
     22636       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800092     22741       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22551       123        .2        .2        .2        .2        .2        .2
     22554       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800093     22746       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22554       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800094     22750       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22642       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800095     22745       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22639       123        .2        .2        .2        .2        .2        .2
     22642       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800096     22751       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22554       123        .8        .8        .8        .8        .8        .8
     22557       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800097     22755       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22642       123        .8        .8        .8        .8        .8        .8
     22645       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800098     22756       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22560       123        .2        .2        .2        .2        .2        .2
     22563       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800099     22761       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22563       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800100     22765       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22651       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800101     22760       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22648       123        .2        .2        .2        .2        .2        .2
     22651       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800102     22766       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22563       123        .8        .8        .8        .8        .8        .8
     22566       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800103     22770       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22651       123        .8        .8        .8        .8        .8        .8
     22654       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800104     22771       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22569       123        .2        .2        .2        .2        .2        .2
     22572       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800105     22776       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22572       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800106     22780       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22660       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800107     22775       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22657       123        .2        .2        .2        .2        .2        .2
     22660       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800108     22781       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22572       123        .8        .8        .8        .8        .8        .8
     22575       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800109     22785       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22660       123        .8        .8        .8        .8        .8        .8
     22663       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800110     22786       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22578       123        .2        .2        .2        .2        .2        .2
     22581       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800111     22791       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22581       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800112     22795       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22669       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800113     22790       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22666       123        .2        .2        .2        .2        .2        .2
     22669       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800114     22796       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22581       123        .8        .8        .8        .8        .8        .8
     22584       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800115     22800       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22669       123        .8        .8        .8        .8        .8        .8
     22672       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800116     22801       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22587       123        .2        .2        .2        .2        .2        .2
     22590       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800117     22806       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22590       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800118     22810       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22678       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800119     22805       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22675       123        .2        .2        .2        .2        .2        .2
     22678       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800120     22811       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22590       123        .8        .8        .8        .8        .8        .8
     22593       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800121     22815       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22678       123        .8        .8        .8        .8        .8        .8
     22681       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800122     22816       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22596       123        .2        .2        .2        .2        .2        .2
     22599       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800123     22821       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22599       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800124     22825       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22687       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800125     22820       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22684       123        .2        .2        .2        .2        .2        .2
     22687       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800126     22826       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22599       123        .8        .8        .8        .8        .8        .8
     22602       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800127     22830       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22687       123        .8        .8        .8        .8        .8        .8
     22690       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800128     22831       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22605       123        .2        .2        .2        .2        .2        .2
     22608       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800129     22836       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22608       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800130     22840       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22696       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800131     22835       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22693       123        .2        .2        .2        .2        .2        .2
     22696       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800132     22841       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22608       123        .8        .8        .8        .8        .8        .8
     22611       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800133     22845       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22696       123        .8        .8        .8        .8        .8        .8
     22699       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800134     22846       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22614       123        .2        .2        .2        .2        .2        .2
     22617       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800135     22847       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22487       123      .184      .184      .184      .184      .184      .184
     22488       123      .016      .016      .016      .016      .016      .016
     22492       123      .736      .736      .736      .736      .736      .736
     22493       123      .064      .064      .064      .064      .064      .064
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800136     22852       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22492       123       .92       .92       .92       .92       .92       .92
     22493       123       .08       .08       .08       .08       .08       .08
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800137     22851       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22617       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800138     22848       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22488       123        .2        .2        .2        .2        .2        .2
     22493       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800139     22853       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22493       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800140     22849       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22488       123      .016      .016      .016      .016      .016      .016
     22489       123      .184      .184      .184      .184      .184      .184
     22493       123      .064      .064      .064      .064      .064      .064
     22494       123      .736      .736      .736      .736      .736      .736
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800141     22854       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22493       123       .08       .08       .08       .08       .08       .08
     22494       123       .92       .92       .92       .92       .92       .92
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800142     22850       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22702       123        .2        .2        .2        .2        .2        .2
     22705       123        .8        .8        .8        .8        .8        .8
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800143     22855       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22705       123         1         1         1         1         1         1
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800144     22857       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22492       123      .736      .736      .736      .736      .736      .736
     22493       123      .064      .064      .064      .064      .064      .064
     22497       123      .184      .184      .184      .184      .184      .184
     22498       123      .016      .016      .016      .016      .016      .016
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800145     22856       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22617       123        .8        .8        .8        .8        .8        .8
     22620       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800146     22858       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22493       123        .8        .8        .8        .8        .8        .8
     22498       123        .2        .2        .2        .2        .2        .2
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800147     22859       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22493       123      .064      .064      .064      .064      .064      .064
     22494       123      .736      .736      .736      .736      .736      .736
     22498       123      .016      .016      .016      .016      .016      .016
     22499       123      .184      .184      .184      .184      .184      .184
$ F0.shaft_front.opening0.leaf0 elevator_closed_panel_reference
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800148     22860       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     22705       123        .8        .8        .8        .8        .8        .8
     22708       123        .2        .2        .2        .2        .2        .2
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800149      7714       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135164       123        .4        .4        .4        .4        .4        .4
    135165       123        .6        .6        .6        .6        .6        .6
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800150      7722       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135165       123         1         1         1         1         1         1
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800151      7723       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135226       123.543797766.543797766.543797766.543797766.543797766.543797766
    135260       123.456202234.456202234.456202234.456202234.456202234.456202234
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800152      7715       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135225       123.217519106.217519106.217519106.217519106.217519106.217519106
    135226       123 .32627866 .32627866 .32627866 .32627866 .32627866 .32627866
    135259       123.182480894.182480894.182480894.182480894.182480894.182480894
    135260       123 .27372134 .27372134 .27372134 .27372134 .27372134 .27372134
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800153      7718       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135361       123 .25023237 .25023237 .25023237 .25023237 .25023237 .25023237
    135362       123.375348555.375348555.375348555.375348555.375348555.375348555
    135395       123 .14976763 .14976763 .14976763 .14976763 .14976763 .14976763
    135396       123.224651445.224651445.224651445.224651445.224651445.224651445
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800154      7726       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135362       123.625580925.625580925.625580925.625580925.625580925.625580925
    135396       123.374419075.374419075.374419075.374419075.374419075.374419075
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800155      7727       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135396       123.455614345.455614345.455614345.455614345.455614345.455614345
    135430       123.544385655.544385655.544385655.544385655.544385655.544385655
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800156      7719       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135395       123.182245738.182245738.182245738.182245738.182245738.182245738
    135396       123.273368607.273368607.273368607.273368607.273368607.273368607
    135429       123.217754262.217754262.217754262.217754262.217754262.217754262
    135430       123.326631393.326631393.326631393.326631393.326631393.326631393
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800157      7728       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135430       123.295238095.295238095.295238095.295238095.295238095.295238095
    135464       123.704761905.704761905.704761905.704761905.704761905.704761905
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800158      7736       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135430       123.177142857.177142857.177142857.177142857.177142857.177142857
    135449       123.118095238.118095238.118095238.118095238.118095238.118095238
    135464       123.422857143.422857143.422857143.422857143.422857143.422857143
    135483       123.281904762.281904762.281904762.281904762.281904762.281904762
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800159      7737       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135498       123        .6        .6        .6        .6        .6        .6
    135517       123        .4        .4        .4        .4        .4        .4
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800160      7729       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135498       123         1         1         1         1         1         1
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800161      7738       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135164       123      .288      .288      .288      .288      .288      .288
    135165       123      .432      .432      .432      .432      .432      .432
    135166       123      .112      .112      .112      .112      .112      .112
    135167       123      .168      .168      .168      .168      .168      .168
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800162      7746       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135165       123       .72       .72       .72       .72       .72       .72
    135167       123       .28       .28       .28       .28       .28       .28
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800163      7754       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135165       123      .432      .432      .432      .432      .432      .432
    135167       123      .168      .168      .168      .168      .168      .168
    135202       123      .288      .288      .288      .288      .288      .288
    135203       123      .112      .112      .112      .112      .112      .112
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800164      7770       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135165       123       .44       .44       .44       .44       .44       .44
    135167       123       .56       .56       .56       .56       .56       .56
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800165      7778       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135165       123      .264      .264      .264      .264      .264      .264
    135167       123      .336      .336      .336      .336      .336      .336
    135202       123      .176      .176      .176      .176      .176      .176
    135203       123      .224      .224      .224      .224      .224      .224
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800166      7724       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135260       123 .37361083 .37361083 .37361083 .37361083 .37361083 .37361083
    135294       123 .62638917 .62638917 .62638917 .62638917 .62638917 .62638917
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800167      7716       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135259       123.149444332.149444332.149444332.149444332.149444332.149444332
    135260       123.224166498.224166498.224166498.224166498.224166498.224166498
    135293       123.250555668.250555668.250555668.250555668.250555668.250555668
    135294       123.375833502.375833502.375833502.375833502.375833502.375833502
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800168      7731       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135226       123 .32627866 .32627866 .32627866 .32627866 .32627866 .32627866
    135245       123.217519106.217519106.217519106.217519106.217519106.217519106
    135260       123 .27372134 .27372134 .27372134 .27372134 .27372134 .27372134
    135279       123.182480894.182480894.182480894.182480894.182480894.182480894
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800169      7732       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135260       123.224166498.224166498.224166498.224166498.224166498.224166498
    135279       123.149444332.149444332.149444332.149444332.149444332.149444332
    135294       123.375833502.375833502.375833502.375833502.375833502.375833502
    135313       123.250555668.250555668.250555668.250555668.250555668.250555668
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800170      7725       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135328       123.999595878.999595878.999595878.999595878.999595878.999595878
    135362       123.000404122.000404122.000404122.000404122.000404122.000404122
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800171      7717       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135327       123.399838351.399838351.399838351.399838351.399838351.399838351
    135328       123.599757527.599757527.599757527.599757527.599757527.599757527
    135361       123.000161649.000161649.000161649.000161649.000161649.000161649
    135362       123.000242473.000242473.000242473.000242473.000242473.000242473
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800172      7720       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135429       123.118095238.118095238.118095238.118095238.118095238.118095238
    135430       123.177142857.177142857.177142857.177142857.177142857.177142857
    135463       123.281904762.281904762.281904762.281904762.281904762.281904762
    135464       123.422857143.422857143.422857143.422857143.422857143.422857143
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800173      7735       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135396       123.273368607.273368607.273368607.273368607.273368607.273368607
    135415       123.182245738.182245738.182245738.182245738.182245738.182245738
    135430       123.326631393.326631393.326631393.326631393.326631393.326631393
    135449       123.217754262.217754262.217754262.217754262.217754262.217754262
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800174      7721       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135497       123        .4        .4        .4        .4        .4        .4
    135498       123        .6        .6        .6        .6        .6        .6
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800175      7753       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135498       123       .72       .72       .72       .72       .72       .72
    135536       123       .28       .28       .28       .28       .28       .28
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800176      7745       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135497       123      .288      .288      .288      .288      .288      .288
    135498       123      .432      .432      .432      .432      .432      .432
    135533       123      .112      .112      .112      .112      .112      .112
    135536       123      .168      .168      .168      .168      .168      .168
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800177      7761       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135498       123      .432      .432      .432      .432      .432      .432
    135517       123      .288      .288      .288      .288      .288      .288
    135536       123      .168      .168      .168      .168      .168      .168
    135589       123      .112      .112      .112      .112      .112      .112
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800178      7785       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135498       123      .264      .264      .264      .264      .264      .264
    135517       123      .176      .176      .176      .176      .176      .176
    135536       123      .336      .336      .336      .336      .336      .336
    135589       123      .224      .224      .224      .224      .224      .224
$ F0.west.back.opening0.frame.bottom frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800179      7777       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135498       123       .44       .44       .44       .44       .44       .44
    135536       123       .56       .56       .56       .56       .56       .56
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800180      7591       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135165       123       .44       .44       .44       .44       .44       .44
    135167       123       .56       .56       .56       .56       .56       .56
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800181      7588       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135164       123      .176      .176      .176      .176      .176      .176
    135165       123      .264      .264      .264      .264      .264      .264
    135166       123      .224      .224      .224      .224      .224      .224
    135167       123      .336      .336      .336      .336      .336      .336
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800182      7597       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135168       123.352761905.352761905.352761905.352761905.352761905.352761905
    135169       123.529142857.529142857.529142857.529142857.529142857.529142857
    135170       123.047238095.047238095.047238095.047238095.047238095.047238095
    135171       123.070857143.070857143.070857143.070857143.070857143.070857143
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800183      7600       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135169       123.881904762.881904762.881904762.881904762.881904762.881904762
    135171       123.118095238.118095238.118095238.118095238.118095238.118095238
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800184      7627       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135175       123.201904762.201904762.201904762.201904762.201904762.201904762
    135177       123.798095238.798095238.798095238.798095238.798095238.798095238
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800185      7624       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135174       123.080761905.080761905.080761905.080761905.080761905.080761905
    135175       123.121142857.121142857.121142857.121142857.121142857.121142857
    135176       123.319238095.319238095.319238095.319238095.319238095.319238095
    135177       123.478857143.478857143.478857143.478857143.478857143.478857143
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800186      7633       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135178       123.390095238.390095238.390095238.390095238.390095238.390095238
    135179       123.585142857.585142857.585142857.585142857.585142857.585142857
    135180       123.009904762.009904762.009904762.009904762.009904762.009904762
    135181       123.014857143.014857143.014857143.014857143.014857143.014857143
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800187      7636       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135179       123.975238095.975238095.975238095.975238095.975238095.975238095
    135181       123.024761905.024761905.024761905.024761905.024761905.024761905
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800188      7594       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135165       123      .264      .264      .264      .264      .264      .264
    135167       123      .336      .336      .336      .336      .336      .336
    135202       123      .176      .176      .176      .176      .176      .176
    135203       123      .224      .224      .224      .224      .224      .224
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800189      7603       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135169       123.529142857.529142857.529142857.529142857.529142857.529142857
    135171       123.070857143.070857143.070857143.070857143.070857143.070857143
    135204       123.352761905.352761905.352761905.352761905.352761905.352761905
    135205       123.047238095.047238095.047238095.047238095.047238095.047238095
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800190      7621       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135173       123.257142857.257142857.257142857.257142857.257142857.257142857
    135175       123.342857143.342857143.342857143.342857143.342857143.342857143
    135206       123.171428571.171428571.171428571.171428571.171428571.171428571
    135207       123.228571429.228571429.228571429.228571429.228571429.228571429
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800191      7618       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135173       123.428571429.428571429.428571429.428571429.428571429.428571429
    135175       123.571428571.571428571.571428571.571428571.571428571.571428571
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800192      7630       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135175       123.121142857.121142857.121142857.121142857.121142857.121142857
    135177       123.478857143.478857143.478857143.478857143.478857143.478857143
    135207       123.080761905.080761905.080761905.080761905.080761905.080761905
    135208       123.319238095.319238095.319238095.319238095.319238095.319238095
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800193      7639       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135179       123.585142857.585142857.585142857.585142857.585142857.585142857
    135181       123.014857143.014857143.014857143.014857143.014857143.014857143
    135209       123.390095238.390095238.390095238.390095238.390095238.390095238
    135210       123.009904762.009904762.009904762.009904762.009904762.009904762
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800194      7645       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135181       123       .12       .12       .12       .12       .12       .12
    135183       123       .88       .88       .88       .88       .88       .88
$ F0.west.back.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800195      7648       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135181       123      .072      .072      .072      .072      .072      .072
    135183       123      .528      .528      .528      .528      .528      .528
    135210       123      .048      .048      .048      .048      .048      .048
    135211       123      .352      .352      .352      .352      .352      .352
$ F0.west.back.opening0.frame.left frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800196      7592       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7771       123.115294118.115294118.115294118.115294118.115294118.115294118
    135165       123.389270588.389270588.389270588.389270588.389270588.389270588
    135167       123.495435294.495435294.495435294.495435294.495435294.495435294
$ F0.west.back.opening0.frame.left frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800197      7589       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7762       123.884705882.884705882.884705882.884705882.884705882.884705882
      7763       123.115294118.115294118.115294118.115294118.115294118.115294118
$ F0.west.back.opening0.frame.left frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800198      7593       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7771       123.230588235.230588235.230588235.230588235.230588235.230588235
    135165       123.338541176.338541176.338541176.338541176.338541176.338541176
    135167       123.430870589.430870589.430870589.430870589.430870589.430870589
$ F0.west.back.opening0.frame.left frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800199      7590       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7762       123.769411765.769411765.769411765.769411765.769411765.769411765
      7763       123.230588235.230588235.230588235.230588235.230588235.230588235
$ F0.west.back.opening0.frame.left frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800200      7595       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7779       123.115294118.115294118.115294118.115294118.115294118.115294118
    135165       123.233562353.233562353.233562353.233562353.233562353.233562353
    135167       123.297261176.297261176.297261176.297261176.297261176.297261176
    135202       123.155708235.155708235.155708235.155708235.155708235.155708235
    135203       123.198174118.198174118.198174118.198174118.198174118.198174118
$ F0.west.back.opening0.frame.left frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800201      7596       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7779       123.230588235.230588235.230588235.230588235.230588235.230588235
    135165       123.203124706.203124706.203124706.203124706.203124706.203124706
    135167       123.258522353.258522353.258522353.258522353.258522353.258522353
    135202       123.135416471.135416471.135416471.135416471.135416471.135416471
    135203       123.172348235.172348235.172348235.172348235.172348235.172348235
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800202      7653       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135497       123      .176      .176      .176      .176      .176      .176
    135498       123      .264      .264      .264      .264      .264      .264
    135533       123      .224      .224      .224      .224      .224      .224
    135536       123      .336      .336      .336      .336      .336      .336
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800203      7656       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135498       123       .44       .44       .44       .44       .44       .44
    135536       123       .56       .56       .56       .56       .56       .56
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800204      7665       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135540       123.881904762.881904762.881904762.881904762.881904762.881904762
    135544       123.118095238.118095238.118095238.118095238.118095238.118095238
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800205      7662       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135537       123.352761905.352761905.352761905.352761905.352761905.352761905
    135540       123.529142857.529142857.529142857.529142857.529142857.529142857
    135541       123.047238095.047238095.047238095.047238095.047238095.047238095
    135544       123.070857143.070857143.070857143.070857143.070857143.070857143
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800206      7689       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135549       123.080761905.080761905.080761905.080761905.080761905.080761905
    135552       123.121142857.121142857.121142857.121142857.121142857.121142857
    135553       123.319238095.319238095.319238095.319238095.319238095.319238095
    135556       123.478857143.478857143.478857143.478857143.478857143.478857143
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800207      7692       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135552       123.201904762.201904762.201904762.201904762.201904762.201904762
    135556       123.798095238.798095238.798095238.798095238.798095238.798095238
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800208      7701       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135560       123.975238095.975238095.975238095.975238095.975238095.975238095
    135564       123.024761905.024761905.024761905.024761905.024761905.024761905
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800209      7698       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135557       123.390095238.390095238.390095238.390095238.390095238.390095238
    135560       123.585142857.585142857.585142857.585142857.585142857.585142857
    135561       123.009904762.009904762.009904762.009904762.009904762.009904762
    135564       123.014857143.014857143.014857143.014857143.014857143.014857143
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800210      7659       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135498       123      .264      .264      .264      .264      .264      .264
    135517       123      .176      .176      .176      .176      .176      .176
    135536       123      .336      .336      .336      .336      .336      .336
    135589       123      .224      .224      .224      .224      .224      .224
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800211      7668       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135540       123.529142857.529142857.529142857.529142857.529142857.529142857
    135544       123.070857143.070857143.070857143.070857143.070857143.070857143
    135591       123.352761905.352761905.352761905.352761905.352761905.352761905
    135593       123.047238095.047238095.047238095.047238095.047238095.047238095
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800212      7683       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135548       123.428571429.428571429.428571429.428571429.428571429.428571429
    135552       123.571428571.571428571.571428571.571428571.571428571.571428571
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800213      7686       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135548       123.257142857.257142857.257142857.257142857.257142857.257142857
    135552       123.342857143.342857143.342857143.342857143.342857143.342857143
    135595       123.171428571.171428571.171428571.171428571.171428571.171428571
    135597       123.228571429.228571429.228571429.228571429.228571429.228571429
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800214      7695       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135552       123.121142857.121142857.121142857.121142857.121142857.121142857
    135556       123.478857143.478857143.478857143.478857143.478857143.478857143
    135597       123.080761905.080761905.080761905.080761905.080761905.080761905
    135599       123.319238095.319238095.319238095.319238095.319238095.319238095
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800215      7704       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135560       123.585142857.585142857.585142857.585142857.585142857.585142857
    135564       123.014857143.014857143.014857143.014857143.014857143.014857143
    135601       123.390095238.390095238.390095238.390095238.390095238.390095238
    135603       123.009904762.009904762.009904762.009904762.009904762.009904762
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800216      7713       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135564       123      .072      .072      .072      .072      .072      .072
    135568       123      .528      .528      .528      .528      .528      .528
    135603       123      .048      .048      .048      .048      .048      .048
    135605       123      .352      .352      .352      .352      .352      .352
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800217      7710       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135564       123       .12       .12       .12       .12       .12       .12
    135568       123       .88       .88       .88       .88       .88       .88
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800218      7677       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135544       123.393142857.393142857.393142857.393142857.393142857.393142857
    135548       123.206857143.206857143.206857143.206857143.206857143.206857143
    135593       123.262095238.262095238.262095238.262095238.262095238.262095238
    135595       123.137904762.137904762.137904762.137904762.137904762.137904762
$ F0.west.back.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800219      7674       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135544       123.655238095.655238095.655238095.655238095.655238095.655238095
    135548       123.344761905.344761905.344761905.344761905.344761905.344761905
$ F0.west.back.opening0.frame.right frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800220      7651       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7768       123.230588235.230588235.230588235.230588235.230588235.230588235
      7769       123.769411765.769411765.769411765.769411765.769411765.769411765
$ F0.west.back.opening0.frame.right frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800221      7654       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7776       123.230588235.230588235.230588235.230588235.230588235.230588235
    135498       123.338541176.338541176.338541176.338541176.338541176.338541176
    135536       123.430870589.430870589.430870589.430870589.430870589.430870589
$ F0.west.back.opening0.frame.right frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800222      7655       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7776       123.115294118.115294118.115294118.115294118.115294118.115294118
    135498       123.389270588.389270588.389270588.389270588.389270588.389270588
    135536       123.495435294.495435294.495435294.495435294.495435294.495435294
$ F0.west.back.opening0.frame.right frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800223      7652       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7768       123.115294118.115294118.115294118.115294118.115294118.115294118
      7769       123.884705882.884705882.884705882.884705882.884705882.884705882
$ F0.west.back.opening0.frame.right frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800224      7657       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7784       123.230588235.230588235.230588235.230588235.230588235.230588235
    135498       123.203124706.203124706.203124706.203124706.203124706.203124706
    135517       123.135416471.135416471.135416471.135416471.135416471.135416471
    135536       123.258522353.258522353.258522353.258522353.258522353.258522353
    135589       123.172348235.172348235.172348235.172348235.172348235.172348235
$ F0.west.back.opening0.frame.right frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800225      7658       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7784       123.115294118.115294118.115294118.115294118.115294118.115294118
    135498       123.233562353.233562353.233562353.233562353.233562353.233562353
    135517       123.155708235.155708235.155708235.155708235.155708235.155708235
    135536       123.297261176.297261176.297261176.297261176.297261176.297261176
    135589       123.198174118.198174118.198174118.198174118.198174118.198174118
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800226      7524       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135181       123       .12       .12       .12       .12       .12       .12
    135183       123       .88       .88       .88       .88       .88       .88
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800227      7516       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135180       123      .048      .048      .048      .048      .048      .048
    135181       123      .072      .072      .072      .072      .072      .072
    135182       123      .352      .352      .352      .352      .352      .352
    135183       123      .528      .528      .528      .528      .528      .528
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800228      7540       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135182       123      .224      .224      .224      .224      .224      .224
    135183       123      .336      .336      .336      .336      .336      .336
    135184       123      .176      .176      .176      .176      .176      .176
    135185       123      .264      .264      .264      .264      .264      .264
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800229      7548       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135183       123       .56       .56       .56       .56       .56       .56
    135185       123       .44       .44       .44       .44       .44       .44
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800230      7556       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135183       123      .336      .336      .336      .336      .336      .336
    135185       123      .264      .264      .264      .264      .264      .264
    135211       123      .224      .224      .224      .224      .224      .224
    135212       123      .176      .176      .176      .176      .176      .176
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800231      7572       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135185       123         1         1         1         1         1         1
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800232      7580       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135185       123        .6        .6        .6        .6        .6        .6
    135212       123        .4        .4        .4        .4        .4        .4
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800233      7523       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135561       123      .048      .048      .048      .048      .048      .048
    135564       123      .072      .072      .072      .072      .072      .072
    135565       123      .352      .352      .352      .352      .352      .352
    135568       123      .528      .528      .528      .528      .528      .528
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800234      7531       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135564       123       .12       .12       .12       .12       .12       .12
    135568       123       .88       .88       .88       .88       .88       .88
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800235      7555       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135500       123       .44       .44       .44       .44       .44       .44
    135568       123       .56       .56       .56       .56       .56       .56
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800236      7547       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135499       123      .176      .176      .176      .176      .176      .176
    135500       123      .264      .264      .264      .264      .264      .264
    135565       123      .224      .224      .224      .224      .224      .224
    135568       123      .336      .336      .336      .336      .336      .336
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800237      7563       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135500       123      .264      .264      .264      .264      .264      .264
    135518       123      .176      .176      .176      .176      .176      .176
    135568       123      .336      .336      .336      .336      .336      .336
    135605       123      .224      .224      .224      .224      .224      .224
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800238      7587       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135500       123        .6        .6        .6        .6        .6        .6
    135518       123        .4        .4        .4        .4        .4        .4
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800239      7579       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135500       123         1         1         1         1         1         1
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800240      7564       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135184       123        .4        .4        .4        .4        .4        .4
    135185       123        .6        .6        .6        .6        .6        .6
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800241      7565       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135227       123.217519106.217519106.217519106.217519106.217519106.217519106
    135228       123 .32627866 .32627866 .32627866 .32627866 .32627866 .32627866
    135261       123.182480894.182480894.182480894.182480894.182480894.182480894
    135262       123 .27372134 .27372134 .27372134 .27372134 .27372134 .27372134
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800242      7573       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135228       123.543797766.543797766.543797766.543797766.543797766.543797766
    135262       123.456202234.456202234.456202234.456202234.456202234.456202234
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800243      7567       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135329       123.399838351.399838351.399838351.399838351.399838351.399838351
    135330       123.599757527.599757527.599757527.599757527.599757527.599757527
    135363       123.000161649.000161649.000161649.000161649.000161649.000161649
    135364       123.000242473.000242473.000242473.000242473.000242473.000242473
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800244      7568       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135363       123 .25023237 .25023237 .25023237 .25023237 .25023237 .25023237
    135364       123.375348555.375348555.375348555.375348555.375348555.375348555
    135397       123 .14976763 .14976763 .14976763 .14976763 .14976763 .14976763
    135398       123.224651445.224651445.224651445.224651445.224651445.224651445
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800245      7576       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135364       123.625580925.625580925.625580925.625580925.625580925.625580925
    135398       123.374419075.374419075.374419075.374419075.374419075.374419075
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800246      7575       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135330       123.999595878.999595878.999595878.999595878.999595878.999595878
    135364       123.000404122.000404122.000404122.000404122.000404122.000404122
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800247      7570       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135431       123.118095238.118095238.118095238.118095238.118095238.118095238
    135432       123.177142857.177142857.177142857.177142857.177142857.177142857
    135465       123.281904762.281904762.281904762.281904762.281904762.281904762
    135466       123.422857143.422857143.422857143.422857143.422857143.422857143
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800248      7571       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135499       123        .4        .4        .4        .4        .4        .4
    135500       123        .6        .6        .6        .6        .6        .6
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800249      7578       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135432       123.295238095.295238095.295238095.295238095.295238095.295238095
    135466       123.704761905.704761905.704761905.704761905.704761905.704761905
$ F0.west.back.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800250      7586       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135432       123.177142857.177142857.177142857.177142857.177142857.177142857
    135450       123.118095238.118095238.118095238.118095238.118095238.118095238
    135466       123.422857143.422857143.422857143.422857143.422857143.422857143
    135484       123.281904762.281904762.281904762.281904762.281904762.281904762
$ F0.west.back.opening0.frame.top frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800251      7532       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135181       123      .072      .072      .072      .072      .072      .072
    135183       123      .528      .528      .528      .528      .528      .528
    135210       123      .048      .048      .048      .048      .048      .048
    135211       123      .352      .352      .352      .352      .352      .352
$ F0.west.back.opening0.frame.top frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800252      7539       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    135564       123      .072      .072      .072      .072      .072      .072
    135568       123      .528      .528      .528      .528      .528      .528
    135603       123      .048      .048      .048      .048      .048      .048
    135605       123      .352      .352      .352      .352      .352      .352
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800253      7786       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7765       123.615294118.615294118.615294118.615294118.615294118.615294118
      7766       123.384705882.384705882.384705882.384705882.384705882.384705882
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800254      7789       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7773       123.615294118.615294118.615294118.615294118.615294118.615294118
      7774       123.384705882.384705882.384705882.384705882.384705882.384705882
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800255      7790       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7773       123        .5        .5        .5        .5        .5        .5
      7774       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800256      7787       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7765       123        .5        .5        .5        .5        .5        .5
      7766       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800257      7791       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7773       123.384705882.384705882.384705882.384705882.384705882.384705882
      7774       123.615294118.615294118.615294118.615294118.615294118.615294118
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800258      7788       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7765       123.384705882.384705882.384705882.384705882.384705882.384705882
      7766       123.615294118.615294118.615294118.615294118.615294118.615294118
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800259      7792       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7781       123.615294118.615294118.615294118.615294118.615294118.615294118
      7782       123.384705882.384705882.384705882.384705882.384705882.384705882
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800260      7793       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7781       123        .5        .5        .5        .5        .5        .5
      7782       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800261      7794       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7781       123.384705882.384705882.384705882.384705882.384705882.384705882
      7782       123.615294118.615294118.615294118.615294118.615294118.615294118
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800262      7840       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7519       123.615294118.615294118.615294118.615294118.615294118.615294118
      7520       123.384705882.384705882.384705882.384705882.384705882.384705882
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800263      7841       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7519       123        .5        .5        .5        .5        .5        .5
      7520       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800264      7844       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7527       123        .5        .5        .5        .5        .5        .5
      7528       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800265      7843       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7527       123.615294118.615294118.615294118.615294118.615294118.615294118
      7528       123.384705882.384705882.384705882.384705882.384705882.384705882
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800266      7842       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7519       123.384705882.384705882.384705882.384705882.384705882.384705882
      7520       123.615294118.615294118.615294118.615294118.615294118.615294118
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800267      7845       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7527       123.384705882.384705882.384705882.384705882.384705882.384705882
      7528       123.615294118.615294118.615294118.615294118.615294118.615294118
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800268      7847       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7535       123        .5        .5        .5        .5        .5        .5
      7536       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800269      7846       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7535       123.615294118.615294118.615294118.615294118.615294118.615294118
      7536       123.384705882.384705882.384705882.384705882.384705882.384705882
$ F0.west.back.opening0.frame.middle frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800270      7848       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7535       123.384705882.384705882.384705882.384705882.384705882.384705882
      7536       123.615294118.615294118.615294118.615294118.615294118.615294118
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800271      7849       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7762       123.115411765.115411765.115411765.115411765.115411765.115411765
      7763       123.034588235.034588235.034588235.034588235.034588235.034588235
      7771       123      .196      .196      .196      .196      .196      .196
    135165       123    .28776    .28776    .28776    .28776    .28776    .28776
    135167       123    .36624    .36624    .36624    .36624    .36624    .36624
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800272      7858       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7771       123.230588235.230588235.230588235.230588235.230588235.230588235
    135165       123.338541176.338541176.338541176.338541176.338541176.338541176
    135167       123.430870589.430870589.430870589.430870589.430870589.430870589
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800273      7859       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7771       123.624852941.624852941.624852941.624852941.624852941.624852941
    135165       123.165064706.165064706.165064706.165064706.165064706.165064706
    135167       123.210082353.210082353.210082353.210082353.210082353.210082353
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800274      7850       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7762       123.056272059.056272059.056272059.056272059.056272059.056272059
      7763       123.093727941.093727941.093727941.093727941.093727941.093727941
      7771       123   .531125   .531125   .531125   .531125   .531125   .531125
    135165       123   .140305   .140305   .140305   .140305   .140305   .140305
    135167       123    .17857    .17857    .17857    .17857    .17857    .17857
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800275      7876       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7599       123      .075      .075      .075      .075      .075      .075
      7602       123      .425      .425      .425      .425      .425      .425
      7762       123.057705882.057705882.057705882.057705882.057705882.057705882
      7763       123.017294118.017294118.017294118.017294118.017294118.017294118
      7771       123      .098      .098      .098      .098      .098      .098
    135165       123    .14388    .14388    .14388    .14388    .14388    .14388
    135167       123    .18312    .18312    .18312    .18312    .18312    .18312
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800276      7885       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7602       123        .5        .5        .5        .5        .5        .5
      7771       123.115294118.115294118.115294118.115294118.115294118.115294118
    135165       123.169270588.169270588.169270588.169270588.169270588.169270588
    135167       123.215435294.215435294.215435294.215435294.215435294.215435294
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800277      7860       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7771       123.980882353.980882353.980882353.980882353.980882353.980882353
      7772       123.019117647.019117647.019117647.019117647.019117647.019117647
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800278      7851       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7763       123.147132353.147132353.147132353.147132353.147132353.147132353
      7764       123.002867647.002867647.002867647.002867647.002867647.002867647
      7771       123    .83375    .83375    .83375    .83375    .83375    .83375
      7772       123    .01625    .01625    .01625    .01625    .01625    .01625
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800279      7861       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7771       123.586617647.586617647.586617647.586617647.586617647.586617647
      7772       123.413382353.413382353.413382353.413382353.413382353.413382353
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800280      7852       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7763       123.087992647.087992647.087992647.087992647.087992647.087992647
      7764       123.062007353.062007353.062007353.062007353.062007353.062007353
      7771       123   .498625   .498625   .498625   .498625   .498625   .498625
      7772       123   .351375   .351375   .351375   .351375   .351375   .351375
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800281      7862       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7771       123.192352941.192352941.192352941.192352941.192352941.192352941
      7772       123.807647059.807647059.807647059.807647059.807647059.807647059
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800282      7853       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7763       123.028852941.028852941.028852941.028852941.028852941.028852941
      7764       123.121147059.121147059.121147059.121147059.121147059.121147059
      7771       123     .1635     .1635     .1635     .1635     .1635     .1635
      7772       123     .6865     .6865     .6865     .6865     .6865     .6865
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800283      7863       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7772       123.798088235.798088235.798088235.798088235.798088235.798088235
      7773       123.201911765.201911765.201911765.201911765.201911765.201911765
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800284      7854       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7764       123.119713235.119713235.119713235.119713235.119713235.119713235
      7765       123.030286765.030286765.030286765.030286765.030286765.030286765
      7772       123   .678375   .678375   .678375   .678375   .678375   .678375
      7773       123   .171625   .171625   .171625   .171625   .171625   .171625
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800285      7864       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7772       123.403823529.403823529.403823529.403823529.403823529.403823529
      7773       123.596176471.596176471.596176471.596176471.596176471.596176471
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800286      7855       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7764       123.060573529.060573529.060573529.060573529.060573529.060573529
      7765       123.089426471.089426471.089426471.089426471.089426471.089426471
      7772       123    .34325    .34325    .34325    .34325    .34325    .34325
      7773       123    .50675    .50675    .50675    .50675    .50675    .50675
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800287      7865       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7772       123.009558824.009558824.009558824.009558824.009558824.009558824
      7773       123.990441176.990441176.990441176.990441176.990441176.990441176
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800288      7856       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7764       123.001433824.001433824.001433824.001433824.001433824.001433824
      7765       123.148566176.148566176.148566176.148566176.148566176.148566176
      7772       123   .008125   .008125   .008125   .008125   .008125   .008125
      7773       123   .841875   .841875   .841875   .841875   .841875   .841875
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800289      7866       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7773       123.615294118.615294118.615294118.615294118.615294118.615294118
      7774       123.384705882.384705882.384705882.384705882.384705882.384705882
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800290      7857       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7765       123.092294118.092294118.092294118.092294118.092294118.092294118
      7766       123.057705882.057705882.057705882.057705882.057705882.057705882
      7773       123      .523      .523      .523      .523      .523      .523
      7774       123      .327      .327      .327      .327      .327      .327
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800291      7893       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7773       123.307647059.307647059.307647059.307647059.307647059.307647059
      7774       123.192352941.192352941.192352941.192352941.192352941.192352941
      7798       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800292      7884       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7765       123.046147059.046147059.046147059.046147059.046147059.046147059
      7766       123.028852941.028852941.028852941.028852941.028852941.028852941
      7773       123     .2615     .2615     .2615     .2615     .2615     .2615
      7774       123     .1635     .1635     .1635     .1635     .1635     .1635
      7795       123      .075      .075      .075      .075      .075      .075
      7798       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800293      7867       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7771       123      .196      .196      .196      .196      .196      .196
      7779       123.034588235.034588235.034588235.034588235.034588235.034588235
    135165       123.318228706.318228706.318228706.318228706.318228706.318228706
    135167       123.405018353.405018353.405018353.405018353.405018353.405018353
    135202       123.020312471.020312471.020312471.020312471.020312471.020312471
    135203       123.025852235.025852235.025852235.025852235.025852235.025852235
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800294      7868       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7771       123   .531125   .531125   .531125   .531125   .531125   .531125
      7779       123.093727941.093727941.093727941.093727941.093727941.093727941
    135165       123.155160824.155160824.155160824.155160824.155160824.155160824
    135167       123.197477412.197477412.197477412.197477412.197477412.197477412
    135202       123.009903882.009903882.009903882.009903882.009903882.009903882
    135203       123.012604941.012604941.012604941.012604941.012604941.012604941
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800295      7894       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7602       123      .425      .425      .425      .425      .425      .425
      7605       123      .075      .075      .075      .075      .075      .075
      7771       123      .098      .098      .098      .098      .098      .098
      7779       123.017294118.017294118.017294118.017294118.017294118.017294118
    135165       123.159114353.159114353.159114353.159114353.159114353.159114353
    135167       123.202509176.202509176.202509176.202509176.202509176.202509176
    135202       123.010156235.010156235.010156235.010156235.010156235.010156235
    135203       123.012926118.012926118.012926118.012926118.012926118.012926118
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800296      7869       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7771       123    .83375    .83375    .83375    .83375    .83375    .83375
      7772       123    .01625    .01625    .01625    .01625    .01625    .01625
      7779       123.147132353.147132353.147132353.147132353.147132353.147132353
      7780       123.002867647.002867647.002867647.002867647.002867647.002867647
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800297      7870       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7771       123   .498625   .498625   .498625   .498625   .498625   .498625
      7772       123   .351375   .351375   .351375   .351375   .351375   .351375
      7779       123.087992647.087992647.087992647.087992647.087992647.087992647
      7780       123.062007353.062007353.062007353.062007353.062007353.062007353
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800298      7871       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7771       123     .1635     .1635     .1635     .1635     .1635     .1635
      7772       123     .6865     .6865     .6865     .6865     .6865     .6865
      7779       123.028852941.028852941.028852941.028852941.028852941.028852941
      7780       123.121147059.121147059.121147059.121147059.121147059.121147059
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800299      7872       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7772       123   .678375   .678375   .678375   .678375   .678375   .678375
      7773       123   .171625   .171625   .171625   .171625   .171625   .171625
      7780       123.119713235.119713235.119713235.119713235.119713235.119713235
      7781       123.030286765.030286765.030286765.030286765.030286765.030286765
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800300      7873       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7772       123    .34325    .34325    .34325    .34325    .34325    .34325
      7773       123    .50675    .50675    .50675    .50675    .50675    .50675
      7780       123.060573529.060573529.060573529.060573529.060573529.060573529
      7781       123.089426471.089426471.089426471.089426471.089426471.089426471
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800301      7874       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7772       123   .008125   .008125   .008125   .008125   .008125   .008125
      7773       123   .841875   .841875   .841875   .841875   .841875   .841875
      7780       123.001433824.001433824.001433824.001433824.001433824.001433824
      7781       123.148566176.148566176.148566176.148566176.148566176.148566176
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800302      7875       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7773       123      .523      .523      .523      .523      .523      .523
      7774       123      .327      .327      .327      .327      .327      .327
      7781       123.092294118.092294118.092294118.092294118.092294118.092294118
      7782       123.057705882.057705882.057705882.057705882.057705882.057705882
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800303      7902       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7773       123     .2615     .2615     .2615     .2615     .2615     .2615
      7774       123     .1635     .1635     .1635     .1635     .1635     .1635
      7781       123.046147059.046147059.046147059.046147059.046147059.046147059
      7782       123.028852941.028852941.028852941.028852941.028852941.028852941
      7798       123      .425      .425      .425      .425      .425      .425
      7801       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800304      7903       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7599       123       .15       .15       .15       .15       .15       .15
      7602       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800305      7912       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7602       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800306      7920       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7798       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800307      7911       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7795       123       .15       .15       .15       .15       .15       .15
      7798       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800308      7921       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7602       123       .85       .85       .85       .85       .85       .85
      7605       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800309      7929       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7798       123       .85       .85       .85       .85       .85       .85
      7801       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800310      7930       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7599       123      .075      .075      .075      .075      .075      .075
      7602       123      .425      .425      .425      .425      .425      .425
      7608       123      .075      .075      .075      .075      .075      .075
      7611       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800311      7939       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7602       123        .5        .5        .5        .5        .5        .5
      7611       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800312      7947       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7798       123        .5        .5        .5        .5        .5        .5
      7807       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800313      7938       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7795       123      .075      .075      .075      .075      .075      .075
      7798       123      .425      .425      .425      .425      .425      .425
      7804       123      .075      .075      .075      .075      .075      .075
      7807       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800314      7948       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7602       123      .425      .425      .425      .425      .425      .425
      7605       123      .075      .075      .075      .075      .075      .075
      7611       123      .425      .425      .425      .425      .425      .425
      7614       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800315      7956       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7798       123      .425      .425      .425      .425      .425      .425
      7801       123      .075      .075      .075      .075      .075      .075
      7807       123      .425      .425      .425      .425      .425      .425
      7810       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800316      7957       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7608       123       .15       .15       .15       .15       .15       .15
      7611       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800317      7966       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7611       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800318      7974       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7807       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800319      7965       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7804       123       .15       .15       .15       .15       .15       .15
      7807       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800320      7975       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7611       123       .85       .85       .85       .85       .85       .85
      7614       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800321      7983       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7807       123       .85       .85       .85       .85       .85       .85
      7810       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800322      7984       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7608       123      .075      .075      .075      .075      .075      .075
      7611       123      .425      .425      .425      .425      .425      .425
      7617       123      .075      .075      .075      .075      .075      .075
      7620       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800323      7993       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7611       123        .5        .5        .5        .5        .5        .5
      7620       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800324      8001       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7807       123        .5        .5        .5        .5        .5        .5
      7816       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800325      7992       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7804       123      .075      .075      .075      .075      .075      .075
      7807       123      .425      .425      .425      .425      .425      .425
      7813       123      .075      .075      .075      .075      .075      .075
      7816       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800326      8002       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7611       123      .425      .425      .425      .425      .425      .425
      7614       123      .075      .075      .075      .075      .075      .075
      7620       123      .425      .425      .425      .425      .425      .425
      7623       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800327      8010       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7807       123      .425      .425      .425      .425      .425      .425
      7810       123      .075      .075      .075      .075      .075      .075
      7816       123      .425      .425      .425      .425      .425      .425
      7819       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800328      8011       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7617       123       .15       .15       .15       .15       .15       .15
      7620       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800329      8020       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7620       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800330      8028       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7816       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800331      8019       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7813       123       .15       .15       .15       .15       .15       .15
      7816       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800332      8029       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7620       123       .85       .85       .85       .85       .85       .85
      7623       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800333      8037       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7816       123       .85       .85       .85       .85       .85       .85
      7819       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800334      8038       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7617       123      .075      .075      .075      .075      .075      .075
      7620       123      .425      .425      .425      .425      .425      .425
      7626       123      .075      .075      .075      .075      .075      .075
      7629       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800335      8047       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7620       123        .5        .5        .5        .5        .5        .5
      7629       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800336      8055       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7816       123        .5        .5        .5        .5        .5        .5
      7825       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800337      8046       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7813       123      .075      .075      .075      .075      .075      .075
      7816       123      .425      .425      .425      .425      .425      .425
      7822       123      .075      .075      .075      .075      .075      .075
      7825       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800338      8056       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7620       123      .425      .425      .425      .425      .425      .425
      7623       123      .075      .075      .075      .075      .075      .075
      7629       123      .425      .425      .425      .425      .425      .425
      7632       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800339      8064       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7816       123      .425      .425      .425      .425      .425      .425
      7819       123      .075      .075      .075      .075      .075      .075
      7825       123      .425      .425      .425      .425      .425      .425
      7828       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800340      8065       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7626       123       .15       .15       .15       .15       .15       .15
      7629       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800341      8074       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7629       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800342      8082       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7825       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800343      8073       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7822       123       .15       .15       .15       .15       .15       .15
      7825       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800344      8083       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7629       123       .85       .85       .85       .85       .85       .85
      7632       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800345      8091       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7825       123       .85       .85       .85       .85       .85       .85
      7828       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800346      8092       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7626       123      .075      .075      .075      .075      .075      .075
      7629       123      .425      .425      .425      .425      .425      .425
      7635       123      .075      .075      .075      .075      .075      .075
      7638       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800347      8101       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7629       123        .5        .5        .5        .5        .5        .5
      7638       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800348      8109       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7825       123        .5        .5        .5        .5        .5        .5
      7834       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800349      8100       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7822       123      .075      .075      .075      .075      .075      .075
      7825       123      .425      .425      .425      .425      .425      .425
      7831       123      .075      .075      .075      .075      .075      .075
      7834       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800350      8110       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7629       123      .425      .425      .425      .425      .425      .425
      7632       123      .075      .075      .075      .075      .075      .075
      7638       123      .425      .425      .425      .425      .425      .425
      7641       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800351      8118       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7825       123      .425      .425      .425      .425      .425      .425
      7828       123      .075      .075      .075      .075      .075      .075
      7834       123      .425      .425      .425      .425      .425      .425
      7837       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800352      8119       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7635       123       .15       .15       .15       .15       .15       .15
      7638       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800353      8128       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7638       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800354      8136       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7834       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800355      8127       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7831       123       .15       .15       .15       .15       .15       .15
      7834       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800356      8137       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7638       123       .85       .85       .85       .85       .85       .85
      7641       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800357      8145       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7834       123       .85       .85       .85       .85       .85       .85
      7837       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800358      8146       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7635       123      .075      .075      .075      .075      .075      .075
      7638       123      .425      .425      .425      .425      .425      .425
      7644       123      .075      .075      .075      .075      .075      .075
      7647       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800359      8155       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7638       123        .5        .5        .5        .5        .5        .5
      7647       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800360      8163       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7527       123.307647059.307647059.307647059.307647059.307647059.307647059
      7528       123.192352941.192352941.192352941.192352941.192352941.192352941
      7834       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800361      8154       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7519       123.046147059.046147059.046147059.046147059.046147059.046147059
      7520       123.028852941.028852941.028852941.028852941.028852941.028852941
      7527       123     .2615     .2615     .2615     .2615     .2615     .2615
      7528       123     .1635     .1635     .1635     .1635     .1635     .1635
      7831       123      .075      .075      .075      .075      .075      .075
      7834       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800362      8164       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7638       123      .425      .425      .425      .425      .425      .425
      7641       123      .075      .075      .075      .075      .075      .075
      7647       123      .425      .425      .425      .425      .425      .425
      7650       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800363      8172       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7527       123     .2615     .2615     .2615     .2615     .2615     .2615
      7528       123     .1635     .1635     .1635     .1635     .1635     .1635
      7535       123.046147059.046147059.046147059.046147059.046147059.046147059
      7536       123.028852941.028852941.028852941.028852941.028852941.028852941
      7834       123      .425      .425      .425      .425      .425      .425
      7837       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800364      8173       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7644       123       .15       .15       .15       .15       .15       .15
      7647       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800365      8174       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7517       123.093727941.093727941.093727941.093727941.093727941.093727941
      7525       123   .531125   .531125   .531125   .531125   .531125   .531125
    135180       123.002701059.002701059.002701059.002701059.002701059.002701059
    135181       123.042316588.042316588.042316588.042316588.042316588.042316588
    135182       123.019807765.019807765.019807765.019807765.019807765.019807765
    135183       123.310321647.310321647.310321647.310321647.310321647.310321647
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800366      8183       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7525       123.624852941.624852941.624852941.624852941.624852941.624852941
    135181       123.045017647.045017647.045017647.045017647.045017647.045017647
    135183       123.330129412.330129412.330129412.330129412.330129412.330129412
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800367      8182       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7647       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800368      8175       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7517       123.147132353.147132353.147132353.147132353.147132353.147132353
      7518       123.002867647.002867647.002867647.002867647.002867647.002867647
      7525       123    .83375    .83375    .83375    .83375    .83375    .83375
      7526       123    .01625    .01625    .01625    .01625    .01625    .01625
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800369      8184       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7525       123.980882353.980882353.980882353.980882353.980882353.980882353
      7526       123.019117647.019117647.019117647.019117647.019117647.019117647
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800370      8176       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7517       123.087992647.087992647.087992647.087992647.087992647.087992647
      7518       123.062007353.062007353.062007353.062007353.062007353.062007353
      7525       123   .498625   .498625   .498625   .498625   .498625   .498625
      7526       123   .351375   .351375   .351375   .351375   .351375   .351375
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800371      8185       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7525       123.586617647.586617647.586617647.586617647.586617647.586617647
      7526       123.413382353.413382353.413382353.413382353.413382353.413382353
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800372      8177       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7517       123.028852941.028852941.028852941.028852941.028852941.028852941
      7518       123.121147059.121147059.121147059.121147059.121147059.121147059
      7525       123     .1635     .1635     .1635     .1635     .1635     .1635
      7526       123     .6865     .6865     .6865     .6865     .6865     .6865
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800373      8186       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7525       123.192352941.192352941.192352941.192352941.192352941.192352941
      7526       123.807647059.807647059.807647059.807647059.807647059.807647059
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800374      8178       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7518       123.119713235.119713235.119713235.119713235.119713235.119713235
      7519       123.030286765.030286765.030286765.030286765.030286765.030286765
      7526       123   .678375   .678375   .678375   .678375   .678375   .678375
      7527       123   .171625   .171625   .171625   .171625   .171625   .171625
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800375      8187       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7526       123.798088235.798088235.798088235.798088235.798088235.798088235
      7527       123.201911765.201911765.201911765.201911765.201911765.201911765
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800376      8179       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7518       123.060573529.060573529.060573529.060573529.060573529.060573529
      7519       123.089426471.089426471.089426471.089426471.089426471.089426471
      7526       123    .34325    .34325    .34325    .34325    .34325    .34325
      7527       123    .50675    .50675    .50675    .50675    .50675    .50675
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800377      8188       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7526       123.403823529.403823529.403823529.403823529.403823529.403823529
      7527       123.596176471.596176471.596176471.596176471.596176471.596176471
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800378      8180       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7518       123.001433824.001433824.001433824.001433824.001433824.001433824
      7519       123.148566176.148566176.148566176.148566176.148566176.148566176
      7526       123   .008125   .008125   .008125   .008125   .008125   .008125
      7527       123   .841875   .841875   .841875   .841875   .841875   .841875
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800379      8189       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7526       123.009558824.009558824.009558824.009558824.009558824.009558824
      7527       123.990441176.990441176.990441176.990441176.990441176.990441176
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800380      8181       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7519       123.092294118.092294118.092294118.092294118.092294118.092294118
      7520       123.057705882.057705882.057705882.057705882.057705882.057705882
      7527       123      .523      .523      .523      .523      .523      .523
      7528       123      .327      .327      .327      .327      .327      .327
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800381      8190       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7527       123.615294118.615294118.615294118.615294118.615294118.615294118
      7528       123.384705882.384705882.384705882.384705882.384705882.384705882
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800382      8192       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7525       123   .531125   .531125   .531125   .531125   .531125   .531125
      7533       123.093727941.093727941.093727941.093727941.093727941.093727941
    135181       123.042316588.042316588.042316588.042316588.042316588.042316588
    135183       123.310321647.310321647.310321647.310321647.310321647.310321647
    135210       123.002701059.002701059.002701059.002701059.002701059.002701059
    135211       123.019807765.019807765.019807765.019807765.019807765.019807765
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800383      8191       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7647       123       .85       .85       .85       .85       .85       .85
      7650       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800384      8193       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7525       123    .83375    .83375    .83375    .83375    .83375    .83375
      7526       123    .01625    .01625    .01625    .01625    .01625    .01625
      7533       123.147132353.147132353.147132353.147132353.147132353.147132353
      7534       123.002867647.002867647.002867647.002867647.002867647.002867647
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800385      8194       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7525       123   .498625   .498625   .498625   .498625   .498625   .498625
      7526       123   .351375   .351375   .351375   .351375   .351375   .351375
      7533       123.087992647.087992647.087992647.087992647.087992647.087992647
      7534       123.062007353.062007353.062007353.062007353.062007353.062007353
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800386      8195       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7525       123     .1635     .1635     .1635     .1635     .1635     .1635
      7526       123     .6865     .6865     .6865     .6865     .6865     .6865
      7533       123.028852941.028852941.028852941.028852941.028852941.028852941
      7534       123.121147059.121147059.121147059.121147059.121147059.121147059
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800387      8196       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7526       123   .678375   .678375   .678375   .678375   .678375   .678375
      7527       123   .171625   .171625   .171625   .171625   .171625   .171625
      7534       123.119713235.119713235.119713235.119713235.119713235.119713235
      7535       123.030286765.030286765.030286765.030286765.030286765.030286765
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800388      8197       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7526       123    .34325    .34325    .34325    .34325    .34325    .34325
      7527       123    .50675    .50675    .50675    .50675    .50675    .50675
      7534       123.060573529.060573529.060573529.060573529.060573529.060573529
      7535       123.089426471.089426471.089426471.089426471.089426471.089426471
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800389      8198       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7526       123   .008125   .008125   .008125   .008125   .008125   .008125
      7527       123   .841875   .841875   .841875   .841875   .841875   .841875
      7534       123.001433824.001433824.001433824.001433824.001433824.001433824
      7535       123.148566176.148566176.148566176.148566176.148566176.148566176
$ F0.west.back.opening0.glass0 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800390      8199       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7527       123      .523      .523      .523      .523      .523      .523
      7528       123      .327      .327      .327      .327      .327      .327
      7535       123.092294118.092294118.092294118.092294118.092294118.092294118
      7536       123.057705882.057705882.057705882.057705882.057705882.057705882
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800391      8200       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7765       123.057705882.057705882.057705882.057705882.057705882.057705882
      7766       123.092294118.092294118.092294118.092294118.092294118.092294118
      7773       123      .327      .327      .327      .327      .327      .327
      7774       123      .523      .523      .523      .523      .523      .523
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800392      8209       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7773       123.384705882.384705882.384705882.384705882.384705882.384705882
      7774       123.615294118.615294118.615294118.615294118.615294118.615294118
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800393      8210       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7774       123.990441176.990441176.990441176.990441176.990441176.990441176
      7775       123.009558824.009558824.009558824.009558824.009558824.009558824
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800394      8201       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7766       123.148566176.148566176.148566176.148566176.148566176.148566176
      7767       123.001433824.001433824.001433824.001433824.001433824.001433824
      7774       123   .841875   .841875   .841875   .841875   .841875   .841875
      7775       123   .008125   .008125   .008125   .008125   .008125   .008125
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800395      8227       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7765       123.028852941.028852941.028852941.028852941.028852941.028852941
      7766       123.046147059.046147059.046147059.046147059.046147059.046147059
      7773       123     .1635     .1635     .1635     .1635     .1635     .1635
      7774       123     .2615     .2615     .2615     .2615     .2615     .2615
      7797       123      .075      .075      .075      .075      .075      .075
      7800       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800396      8236       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7773       123.192352941.192352941.192352941.192352941.192352941.192352941
      7774       123.307647059.307647059.307647059.307647059.307647059.307647059
      7800       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800397      8211       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7774       123.596176471.596176471.596176471.596176471.596176471.596176471
      7775       123.403823529.403823529.403823529.403823529.403823529.403823529
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800398      8202       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7766       123.089426471.089426471.089426471.089426471.089426471.089426471
      7767       123.060573529.060573529.060573529.060573529.060573529.060573529
      7774       123    .50675    .50675    .50675    .50675    .50675    .50675
      7775       123    .34325    .34325    .34325    .34325    .34325    .34325
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800399      8212       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7774       123.201911765.201911765.201911765.201911765.201911765.201911765
      7775       123.798088235.798088235.798088235.798088235.798088235.798088235
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800400      8203       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7766       123.030286765.030286765.030286765.030286765.030286765.030286765
      7767       123.119713235.119713235.119713235.119713235.119713235.119713235
      7774       123   .171625   .171625   .171625   .171625   .171625   .171625
      7775       123   .678375   .678375   .678375   .678375   .678375   .678375
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800401      8213       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7775       123.807647059.807647059.807647059.807647059.807647059.807647059
      7776       123.192352941.192352941.192352941.192352941.192352941.192352941
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800402      8204       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7767       123.121147059.121147059.121147059.121147059.121147059.121147059
      7768       123.028852941.028852941.028852941.028852941.028852941.028852941
      7775       123     .6865     .6865     .6865     .6865     .6865     .6865
      7776       123     .1635     .1635     .1635     .1635     .1635     .1635
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800403      8214       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7775       123.413382353.413382353.413382353.413382353.413382353.413382353
      7776       123.586617647.586617647.586617647.586617647.586617647.586617647
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800404      8205       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7767       123.062007353.062007353.062007353.062007353.062007353.062007353
      7768       123.087992647.087992647.087992647.087992647.087992647.087992647
      7775       123   .351375   .351375   .351375   .351375   .351375   .351375
      7776       123   .498625   .498625   .498625   .498625   .498625   .498625
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800405      8215       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7775       123.019117647.019117647.019117647.019117647.019117647.019117647
      7776       123.980882353.980882353.980882353.980882353.980882353.980882353
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800406      8206       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7767       123.002867647.002867647.002867647.002867647.002867647.002867647
      7768       123.147132353.147132353.147132353.147132353.147132353.147132353
      7775       123    .01625    .01625    .01625    .01625    .01625    .01625
      7776       123    .83375    .83375    .83375    .83375    .83375    .83375
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800407      8216       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7776       123.624852941.624852941.624852941.624852941.624852941.624852941
    135498       123.165064706.165064706.165064706.165064706.165064706.165064706
    135536       123.210082353.210082353.210082353.210082353.210082353.210082353
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800408      8207       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7768       123.093727941.093727941.093727941.093727941.093727941.093727941
      7769       123.056272059.056272059.056272059.056272059.056272059.056272059
      7776       123   .531125   .531125   .531125   .531125   .531125   .531125
    135498       123   .140305   .140305   .140305   .140305   .140305   .140305
    135536       123    .17857    .17857    .17857    .17857    .17857    .17857
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800409      8217       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7776       123.230588235.230588235.230588235.230588235.230588235.230588235
    135498       123.338541176.338541176.338541176.338541176.338541176.338541176
    135536       123.430870589.430870589.430870589.430870589.430870589.430870589
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800410      8208       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7768       123.034588235.034588235.034588235.034588235.034588235.034588235
      7769       123.115411765.115411765.115411765.115411765.115411765.115411765
      7776       123      .196      .196      .196      .196      .196      .196
    135498       123    .28776    .28776    .28776    .28776    .28776    .28776
    135536       123    .36624    .36624    .36624    .36624    .36624    .36624
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800411      8244       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7663       123        .5        .5        .5        .5        .5        .5
      7776       123.115294118.115294118.115294118.115294118.115294118.115294118
    135498       123.169270588.169270588.169270588.169270588.169270588.169270588
    135536       123.215435294.215435294.215435294.215435294.215435294.215435294
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800412      8235       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7660       123      .075      .075      .075      .075      .075      .075
      7663       123      .425      .425      .425      .425      .425      .425
      7768       123.017294118.017294118.017294118.017294118.017294118.017294118
      7769       123.057705882.057705882.057705882.057705882.057705882.057705882
      7776       123      .098      .098      .098      .098      .098      .098
    135498       123    .14388    .14388    .14388    .14388    .14388    .14388
    135536       123    .18312    .18312    .18312    .18312    .18312    .18312
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800413      8218       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7773       123      .327      .327      .327      .327      .327      .327
      7774       123      .523      .523      .523      .523      .523      .523
      7781       123.057705882.057705882.057705882.057705882.057705882.057705882
      7782       123.092294118.092294118.092294118.092294118.092294118.092294118
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800414      8219       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7774       123   .841875   .841875   .841875   .841875   .841875   .841875
      7775       123   .008125   .008125   .008125   .008125   .008125   .008125
      7782       123.148566176.148566176.148566176.148566176.148566176.148566176
      7783       123.001433824.001433824.001433824.001433824.001433824.001433824
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800415      8245       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7773       123     .1635     .1635     .1635     .1635     .1635     .1635
      7774       123     .2615     .2615     .2615     .2615     .2615     .2615
      7781       123.028852941.028852941.028852941.028852941.028852941.028852941
      7782       123.046147059.046147059.046147059.046147059.046147059.046147059
      7800       123      .425      .425      .425      .425      .425      .425
      7803       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800416      8220       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7774       123    .50675    .50675    .50675    .50675    .50675    .50675
      7775       123    .34325    .34325    .34325    .34325    .34325    .34325
      7782       123.089426471.089426471.089426471.089426471.089426471.089426471
      7783       123.060573529.060573529.060573529.060573529.060573529.060573529
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800417      8221       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7774       123   .171625   .171625   .171625   .171625   .171625   .171625
      7775       123   .678375   .678375   .678375   .678375   .678375   .678375
      7782       123.030286765.030286765.030286765.030286765.030286765.030286765
      7783       123.119713235.119713235.119713235.119713235.119713235.119713235
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800418      8222       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7775       123     .6865     .6865     .6865     .6865     .6865     .6865
      7776       123     .1635     .1635     .1635     .1635     .1635     .1635
      7783       123.121147059.121147059.121147059.121147059.121147059.121147059
      7784       123.028852941.028852941.028852941.028852941.028852941.028852941
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800419      8223       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7775       123   .351375   .351375   .351375   .351375   .351375   .351375
      7776       123   .498625   .498625   .498625   .498625   .498625   .498625
      7783       123.062007353.062007353.062007353.062007353.062007353.062007353
      7784       123.087992647.087992647.087992647.087992647.087992647.087992647
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800420      8224       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7775       123    .01625    .01625    .01625    .01625    .01625    .01625
      7776       123    .83375    .83375    .83375    .83375    .83375    .83375
      7783       123.002867647.002867647.002867647.002867647.002867647.002867647
      7784       123.147132353.147132353.147132353.147132353.147132353.147132353
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800421      8225       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7776       123   .531125   .531125   .531125   .531125   .531125   .531125
      7784       123.093727941.093727941.093727941.093727941.093727941.093727941
    135498       123.155160824.155160824.155160824.155160824.155160824.155160824
    135517       123.009903882.009903882.009903882.009903882.009903882.009903882
    135536       123.197477412.197477412.197477412.197477412.197477412.197477412
    135589       123.012604941.012604941.012604941.012604941.012604941.012604941
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800422      8226       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7776       123      .196      .196      .196      .196      .196      .196
      7784       123.034588235.034588235.034588235.034588235.034588235.034588235
    135498       123.318228706.318228706.318228706.318228706.318228706.318228706
    135517       123.020312471.020312471.020312471.020312471.020312471.020312471
    135536       123.405018353.405018353.405018353.405018353.405018353.405018353
    135589       123.025852235.025852235.025852235.025852235.025852235.025852235
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800423      8253       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7663       123      .425      .425      .425      .425      .425      .425
      7666       123      .075      .075      .075      .075      .075      .075
      7776       123      .098      .098      .098      .098      .098      .098
      7784       123.017294118.017294118.017294118.017294118.017294118.017294118
    135498       123.159114353.159114353.159114353.159114353.159114353.159114353
    135517       123.010156235.010156235.010156235.010156235.010156235.010156235
    135536       123.202509176.202509176.202509176.202509176.202509176.202509176
    135589       123.012926118.012926118.012926118.012926118.012926118.012926118
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800424      8254       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7797       123       .15       .15       .15       .15       .15       .15
      7800       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800425      8263       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7800       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800426      8271       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7663       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800427      8262       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7660       123       .15       .15       .15       .15       .15       .15
      7663       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800428      8272       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7800       123       .85       .85       .85       .85       .85       .85
      7803       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800429      8280       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7663       123       .85       .85       .85       .85       .85       .85
      7666       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800430      8281       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7797       123      .075      .075      .075      .075      .075      .075
      7800       123      .425      .425      .425      .425      .425      .425
      7806       123      .075      .075      .075      .075      .075      .075
      7809       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800431      8290       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7800       123        .5        .5        .5        .5        .5        .5
      7809       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800432      8298       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7663       123        .5        .5        .5        .5        .5        .5
      7672       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800433      8289       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7660       123      .075      .075      .075      .075      .075      .075
      7663       123      .425      .425      .425      .425      .425      .425
      7669       123      .075      .075      .075      .075      .075      .075
      7672       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800434      8299       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7800       123      .425      .425      .425      .425      .425      .425
      7803       123      .075      .075      .075      .075      .075      .075
      7809       123      .425      .425      .425      .425      .425      .425
      7812       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800435      8307       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7663       123      .425      .425      .425      .425      .425      .425
      7666       123      .075      .075      .075      .075      .075      .075
      7672       123      .425      .425      .425      .425      .425      .425
      7675       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800436      8308       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7806       123       .15       .15       .15       .15       .15       .15
      7809       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800437      8317       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7809       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800438      8325       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7672       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800439      8316       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7669       123       .15       .15       .15       .15       .15       .15
      7672       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800440      8326       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7809       123       .85       .85       .85       .85       .85       .85
      7812       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800441      8334       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7672       123       .85       .85       .85       .85       .85       .85
      7675       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800442      8335       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7806       123      .075      .075      .075      .075      .075      .075
      7809       123      .425      .425      .425      .425      .425      .425
      7815       123      .075      .075      .075      .075      .075      .075
      7818       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800443      8344       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7809       123        .5        .5        .5        .5        .5        .5
      7818       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800444      8352       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7672       123        .5        .5        .5        .5        .5        .5
      7681       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800445      8343       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7669       123      .075      .075      .075      .075      .075      .075
      7672       123      .425      .425      .425      .425      .425      .425
      7678       123      .075      .075      .075      .075      .075      .075
      7681       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800446      8353       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7809       123      .425      .425      .425      .425      .425      .425
      7812       123      .075      .075      .075      .075      .075      .075
      7818       123      .425      .425      .425      .425      .425      .425
      7821       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800447      8361       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7672       123      .425      .425      .425      .425      .425      .425
      7675       123      .075      .075      .075      .075      .075      .075
      7681       123      .425      .425      .425      .425      .425      .425
      7684       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800448      8362       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7815       123       .15       .15       .15       .15       .15       .15
      7818       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800449      8371       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7818       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800450      8379       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7681       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800451      8370       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7678       123       .15       .15       .15       .15       .15       .15
      7681       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800452      8380       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7818       123       .85       .85       .85       .85       .85       .85
      7821       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800453      8388       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7681       123       .85       .85       .85       .85       .85       .85
      7684       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800454      8389       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7815       123      .075      .075      .075      .075      .075      .075
      7818       123      .425      .425      .425      .425      .425      .425
      7824       123      .075      .075      .075      .075      .075      .075
      7827       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800455      8398       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7818       123        .5        .5        .5        .5        .5        .5
      7827       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800456      8406       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7681       123        .5        .5        .5        .5        .5        .5
      7690       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800457      8397       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7678       123      .075      .075      .075      .075      .075      .075
      7681       123      .425      .425      .425      .425      .425      .425
      7687       123      .075      .075      .075      .075      .075      .075
      7690       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800458      8407       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7818       123      .425      .425      .425      .425      .425      .425
      7821       123      .075      .075      .075      .075      .075      .075
      7827       123      .425      .425      .425      .425      .425      .425
      7830       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800459      8415       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7681       123      .425      .425      .425      .425      .425      .425
      7684       123      .075      .075      .075      .075      .075      .075
      7690       123      .425      .425      .425      .425      .425      .425
      7693       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800460      8416       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7824       123       .15       .15       .15       .15       .15       .15
      7827       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800461      8425       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7827       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800462      8433       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7690       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800463      8424       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7687       123       .15       .15       .15       .15       .15       .15
      7690       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800464      8434       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7827       123       .85       .85       .85       .85       .85       .85
      7830       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800465      8442       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7690       123       .85       .85       .85       .85       .85       .85
      7693       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800466      8443       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7824       123      .075      .075      .075      .075      .075      .075
      7827       123      .425      .425      .425      .425      .425      .425
      7833       123      .075      .075      .075      .075      .075      .075
      7836       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800467      8452       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7827       123        .5        .5        .5        .5        .5        .5
      7836       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800468      8460       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7690       123        .5        .5        .5        .5        .5        .5
      7699       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800469      8451       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7687       123      .075      .075      .075      .075      .075      .075
      7690       123      .425      .425      .425      .425      .425      .425
      7696       123      .075      .075      .075      .075      .075      .075
      7699       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800470      8461       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7827       123      .425      .425      .425      .425      .425      .425
      7830       123      .075      .075      .075      .075      .075      .075
      7836       123      .425      .425      .425      .425      .425      .425
      7839       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800471      8469       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7690       123      .425      .425      .425      .425      .425      .425
      7693       123      .075      .075      .075      .075      .075      .075
      7699       123      .425      .425      .425      .425      .425      .425
      7702       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800472      8470       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7833       123       .15       .15       .15       .15       .15       .15
      7836       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800473      8479       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7836       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800474      8487       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7699       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800475      8478       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7696       123       .15       .15       .15       .15       .15       .15
      7699       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800476      8488       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7836       123       .85       .85       .85       .85       .85       .85
      7839       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800477      8496       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7699       123       .85       .85       .85       .85       .85       .85
      7702       123       .15       .15       .15       .15       .15       .15
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800478      8497       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7519       123.028852941.028852941.028852941.028852941.028852941.028852941
      7520       123.046147059.046147059.046147059.046147059.046147059.046147059
      7527       123     .1635     .1635     .1635     .1635     .1635     .1635
      7528       123     .2615     .2615     .2615     .2615     .2615     .2615
      7833       123      .075      .075      .075      .075      .075      .075
      7836       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800479      8506       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7527       123.192352941.192352941.192352941.192352941.192352941.192352941
      7528       123.307647059.307647059.307647059.307647059.307647059.307647059
      7836       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800480      8514       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7699       123        .5        .5        .5        .5        .5        .5
      7708       123        .5        .5        .5        .5        .5        .5
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800481      8505       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7696       123      .075      .075      .075      .075      .075      .075
      7699       123      .425      .425      .425      .425      .425      .425
      7705       123      .075      .075      .075      .075      .075      .075
      7708       123      .425      .425      .425      .425      .425      .425
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800482      8515       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7527       123     .1635     .1635     .1635     .1635     .1635     .1635
      7528       123     .2615     .2615     .2615     .2615     .2615     .2615
      7535       123.028852941.028852941.028852941.028852941.028852941.028852941
      7536       123.046147059.046147059.046147059.046147059.046147059.046147059
      7836       123      .425      .425      .425      .425      .425      .425
      7839       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800483      8523       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7699       123      .425      .425      .425      .425      .425      .425
      7702       123      .075      .075      .075      .075      .075      .075
      7708       123      .425      .425      .425      .425      .425      .425
      7711       123      .075      .075      .075      .075      .075      .075
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800484      8524       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7519       123.057705882.057705882.057705882.057705882.057705882.057705882
      7520       123.092294118.092294118.092294118.092294118.092294118.092294118
      7527       123      .327      .327      .327      .327      .327      .327
      7528       123      .523      .523      .523      .523      .523      .523
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800485      8525       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7520       123.148566176.148566176.148566176.148566176.148566176.148566176
      7521       123.001433824.001433824.001433824.001433824.001433824.001433824
      7528       123   .841875   .841875   .841875   .841875   .841875   .841875
      7529       123   .008125   .008125   .008125   .008125   .008125   .008125
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800486      8534       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7528       123.990441176.990441176.990441176.990441176.990441176.990441176
      7529       123.009558824.009558824.009558824.009558824.009558824.009558824
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800487      8533       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7527       123.384705882.384705882.384705882.384705882.384705882.384705882
      7528       123.615294118.615294118.615294118.615294118.615294118.615294118
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800488      8526       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7520       123.089426471.089426471.089426471.089426471.089426471.089426471
      7521       123.060573529.060573529.060573529.060573529.060573529.060573529
      7528       123    .50675    .50675    .50675    .50675    .50675    .50675
      7529       123    .34325    .34325    .34325    .34325    .34325    .34325
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800489      8535       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7528       123.596176471.596176471.596176471.596176471.596176471.596176471
      7529       123.403823529.403823529.403823529.403823529.403823529.403823529
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800490      8527       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7520       123.030286765.030286765.030286765.030286765.030286765.030286765
      7521       123.119713235.119713235.119713235.119713235.119713235.119713235
      7528       123   .171625   .171625   .171625   .171625   .171625   .171625
      7529       123   .678375   .678375   .678375   .678375   .678375   .678375
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800491      8536       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7528       123.201911765.201911765.201911765.201911765.201911765.201911765
      7529       123.798088235.798088235.798088235.798088235.798088235.798088235
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800492      8528       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7521       123.121147059.121147059.121147059.121147059.121147059.121147059
      7522       123.028852941.028852941.028852941.028852941.028852941.028852941
      7529       123     .6865     .6865     .6865     .6865     .6865     .6865
      7530       123     .1635     .1635     .1635     .1635     .1635     .1635
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800493      8537       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7529       123.807647059.807647059.807647059.807647059.807647059.807647059
      7530       123.192352941.192352941.192352941.192352941.192352941.192352941
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800494      8529       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7521       123.062007353.062007353.062007353.062007353.062007353.062007353
      7522       123.087992647.087992647.087992647.087992647.087992647.087992647
      7529       123   .351375   .351375   .351375   .351375   .351375   .351375
      7530       123   .498625   .498625   .498625   .498625   .498625   .498625
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800495      8538       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7529       123.413382353.413382353.413382353.413382353.413382353.413382353
      7530       123.586617647.586617647.586617647.586617647.586617647.586617647
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800496      8530       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7521       123.002867647.002867647.002867647.002867647.002867647.002867647
      7522       123.147132353.147132353.147132353.147132353.147132353.147132353
      7529       123    .01625    .01625    .01625    .01625    .01625    .01625
      7530       123    .83375    .83375    .83375    .83375    .83375    .83375
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800497      8539       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7529       123.019117647.019117647.019117647.019117647.019117647.019117647
      7530       123.980882353.980882353.980882353.980882353.980882353.980882353
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800498      8531       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7522       123.093727941.093727941.093727941.093727941.093727941.093727941
      7530       123   .531125   .531125   .531125   .531125   .531125   .531125
    135561       123.002701059.002701059.002701059.002701059.002701059.002701059
    135564       123.042316588.042316588.042316588.042316588.042316588.042316588
    135565       123.019807765.019807765.019807765.019807765.019807765.019807765
    135568       123.310321647.310321647.310321647.310321647.310321647.310321647
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800499      8540       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7530       123.624852941.624852941.624852941.624852941.624852941.624852941
    135564       123.045017647.045017647.045017647.045017647.045017647.045017647
    135568       123.330129412.330129412.330129412.330129412.330129412.330129412
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800500      8532       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7705       123       .15       .15       .15       .15       .15       .15
      7708       123       .85       .85       .85       .85       .85       .85
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800501      8541       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7708       123         1         1         1         1         1         1
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800502      8543       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7528       123   .841875   .841875   .841875   .841875   .841875   .841875
      7529       123   .008125   .008125   .008125   .008125   .008125   .008125
      7536       123.148566176.148566176.148566176.148566176.148566176.148566176
      7537       123.001433824.001433824.001433824.001433824.001433824.001433824
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800503      8542       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7527       123      .327      .327      .327      .327      .327      .327
      7528       123      .523      .523      .523      .523      .523      .523
      7535       123.057705882.057705882.057705882.057705882.057705882.057705882
      7536       123.092294118.092294118.092294118.092294118.092294118.092294118
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800504      8544       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7528       123    .50675    .50675    .50675    .50675    .50675    .50675
      7529       123    .34325    .34325    .34325    .34325    .34325    .34325
      7536       123.089426471.089426471.089426471.089426471.089426471.089426471
      7537       123.060573529.060573529.060573529.060573529.060573529.060573529
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800505      8545       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7528       123   .171625   .171625   .171625   .171625   .171625   .171625
      7529       123   .678375   .678375   .678375   .678375   .678375   .678375
      7536       123.030286765.030286765.030286765.030286765.030286765.030286765
      7537       123.119713235.119713235.119713235.119713235.119713235.119713235
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800506      8546       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7529       123     .6865     .6865     .6865     .6865     .6865     .6865
      7530       123     .1635     .1635     .1635     .1635     .1635     .1635
      7537       123.121147059.121147059.121147059.121147059.121147059.121147059
      7538       123.028852941.028852941.028852941.028852941.028852941.028852941
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800507      8547       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7529       123   .351375   .351375   .351375   .351375   .351375   .351375
      7530       123   .498625   .498625   .498625   .498625   .498625   .498625
      7537       123.062007353.062007353.062007353.062007353.062007353.062007353
      7538       123.087992647.087992647.087992647.087992647.087992647.087992647
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800508      8548       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7529       123    .01625    .01625    .01625    .01625    .01625    .01625
      7530       123    .83375    .83375    .83375    .83375    .83375    .83375
      7537       123.002867647.002867647.002867647.002867647.002867647.002867647
      7538       123.147132353.147132353.147132353.147132353.147132353.147132353
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800509      8549       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7530       123   .531125   .531125   .531125   .531125   .531125   .531125
      7538       123.093727941.093727941.093727941.093727941.093727941.093727941
    135564       123.042316588.042316588.042316588.042316588.042316588.042316588
    135568       123.310321647.310321647.310321647.310321647.310321647.310321647
    135603       123.002701059.002701059.002701059.002701059.002701059.002701059
    135605       123.019807765.019807765.019807765.019807765.019807765.019807765
$ F0.west.back.opening0.glass1 glass_edge_support
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800510      8550       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
      7708       123       .85       .85       .85       .85       .85       .85
      7711       123       .15       .15       .15       .15       .15       .15
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800511      6976       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     84581       123         1         1         1         1         1         1
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800512      6979       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     84583       123         1         1         1         1         1         1
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800513      6980       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     84583       123.919678715.919678715.919678715.919678715.919678715.919678715
     84630       123.080321285.080321285.080321285.080321285.080321285.080321285
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800514      6977       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     84581       123.919678715.919678715.919678715.919678715.919678715.919678715
     84628       123.080321285.080321285.080321285.080321285.080321285.080321285
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800515      6981       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     84583       123 .83935743 .83935743 .83935743 .83935743 .83935743 .83935743
     84630       123 .16064257 .16064257 .16064257 .16064257 .16064257 .16064257
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800516      6985       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85709       123.844444444.844444444.844444444.844444444.844444444.844444444
     85711       123.155555556.155555556.155555556.155555556.155555556.155555556
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800517      6988       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85710       123.844444444.844444444.844444444.844444444.844444444.844444444
     85712       123.155555556.155555556.155555556.155555556.155555556.155555556
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800518      7015       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85716       123.433333333.433333333.433333333.433333333.433333333.433333333
     85718       123.566666667.566666667.566666667.566666667.566666667.566666667
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800519      7012       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85715       123.433333333.433333333.433333333.433333333.433333333.433333333
     85717       123.566666667.566666667.566666667.566666667.566666667.566666667
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800520      7021       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85717       123.380952381.380952381.380952381.380952381.380952381.380952381
     85719       123.619047619.619047619.619047619.619047619.619047619.619047619
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800521      7024       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85718       123.380952381.380952381.380952381.380952381.380952381.380952381
     85720       123.619047619.619047619.619047619.619047619.619047619.619047619
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800522      7042       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85722       123.276190476.276190476.276190476.276190476.276190476.276190476
     85724       123.723809524.723809524.723809524.723809524.723809524.723809524
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800523      7039       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85721       123.276190476.276190476.276190476.276190476.276190476.276190476
     85723       123.723809524.723809524.723809524.723809524.723809524.723809524
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800524      7048       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85723       123.223809524.223809524.223809524.223809524.223809524.223809524
     85725       123.776190476.776190476.776190476.776190476.776190476.776190476
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800525      7051       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85724       123.223809524.223809524.223809524.223809524.223809524.223809524
     85726       123.776190476.776190476.776190476.776190476.776190476.776190476
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800526      6982       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     84585       123         1         1         1         1         1         1
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800527      6991       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85741       123.844444444.844444444.844444444.844444444.844444444.844444444
     85742       123.155555556.155555556.155555556.155555556.155555556.155555556
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800528      7018       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85744       123.433333333.433333333.433333333.433333333.433333333.433333333
     85745       123.566666667.566666667.566666667.566666667.566666667.566666667
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800529      7027       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85745       123.380952381.380952381.380952381.380952381.380952381.380952381
     85746       123.619047619.619047619.619047619.619047619.619047619.619047619
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800530      7045       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85747       123.276190476.276190476.276190476.276190476.276190476.276190476
     85748       123.723809524.723809524.723809524.723809524.723809524.723809524
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800531      7054       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85748       123.223809524.223809524.223809524.223809524.223809524.223809524
     85749       123.776190476.776190476.776190476.776190476.776190476.776190476
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800532      7060       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85726       123.171428571.171428571.171428571.171428571.171428571.171428571
     85728       123.828571429.828571429.828571429.828571429.828571429.828571429
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800533      7063       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85749       123.171428571.171428571.171428571.171428571.171428571.171428571
     85750       123.828571429.828571429.828571429.828571429.828571429.828571429
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800534      6994       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85711       123.688888889.688888889.688888889.688888889.688888889.688888889
     85713       123.311111111.311111111.311111111.311111111.311111111.311111111
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800535      6997       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85712       123.688888889.688888889.688888889.688888889.688888889.688888889
     85714       123.311111111.311111111.311111111.311111111.311111111.311111111
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800536      7003       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85713       123.533333333.533333333.533333333.533333333.533333333.533333333
     85715       123.466666667.466666667.466666667.466666667.466666667.466666667
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800537      7006       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85714       123.533333333.533333333.533333333.533333333.533333333.533333333
     85716       123.466666667.466666667.466666667.466666667.466666667.466666667
$ F0.west.front.opening0.frame.left frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800538      7009       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85743       123.533333333.533333333.533333333.533333333.533333333.533333333
     85744       123.466666667.466666667.466666667.466666667.466666667.466666667
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800539      7066       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    146459       123.727272727.727272727.727272727.727272727.727272727.727272727
    146506       123.272727273.272727273.272727273.272727273.272727273.272727273
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800540      7069       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    146461       123.727272727.727272727.727272727.727272727.727272727.727272727
    146508       123.272727273.272727273.272727273.272727273.272727273.272727273
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800541      7070       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    146461       123.363636364.363636364.363636364.363636364.363636364.363636364
    146508       123.636363636.636363636.636363636.636363636.636363636.636363636
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800542      7067       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    146459       123.363636364.363636364.363636364.363636364.363636364.363636364
    146506       123.636363636.636363636.636363636.636363636.636363636.636363636
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800543      7074       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    146510       123         1         1         1         1         1         1
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800544      7071       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    146508       123         1         1         1         1         1         1
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800545      7068       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    146506       123         1         1         1         1         1         1
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800546      7080       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147633       123.844444444.844444444.844444444.844444444.844444444.844444444
    147637       123.155555556.155555556.155555556.155555556.155555556.155555556
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800547      7077       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147630       123.844444444.844444444.844444444.844444444.844444444.844444444
    147634       123.155555556.155555556.155555556.155555556.155555556.155555556
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800548      7095       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147638       123.533333333.533333333.533333333.533333333.533333333.533333333
    147642       123.466666667.466666667.466666667.466666667.466666667.466666667
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800549      7098       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147641       123.533333333.533333333.533333333.533333333.533333333.533333333
    147645       123.466666667.466666667.466666667.466666667.466666667.466666667
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800550      7107       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147649       123.785185185.785185185.785185185.785185185.785185185.785185185
    147653       123.214814815.214814815.214814815.214814815.214814815.214814815
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800551      7104       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147646       123.785185185.785185185.785185185.785185185.785185185.785185185
    147650       123.214814815.214814815.214814815.214814815.214814815.214814815
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800552      7122       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147658       123.866666667.866666667.866666667.866666667.866666667.866666667
    147662       123.133333333.133333333.133333333.133333333.133333333.133333333
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800553      7125       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147661       123.866666667.866666667.866666667.866666667.866666667.866666667
    147665       123.133333333.133333333.133333333.133333333.133333333.133333333
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800554      7134       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147665       123.463492063.463492063.463492063.463492063.463492063.463492063
    147669       123.536507937.536507937.536507937.536507937.536507937.536507937
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800555      7131       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147662       123.463492063.463492063.463492063.463492063.463492063.463492063
    147666       123.536507937.536507937.536507937.536507937.536507937.536507937
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800556      7083       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147697       123.844444444.844444444.844444444.844444444.844444444.844444444
    147699       123.155555556.155555556.155555556.155555556.155555556.155555556
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800557      7101       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147701       123.533333333.533333333.533333333.533333333.533333333.533333333
    147703       123.466666667.466666667.466666667.466666667.466666667.466666667
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800558      7110       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147705       123.785185185.785185185.785185185.785185185.785185185.785185185
    147707       123.214814815.214814815.214814815.214814815.214814815.214814815
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800559      7128       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147711       123.866666667.866666667.866666667.866666667.866666667.866666667
    147713       123.133333333.133333333.133333333.133333333.133333333.133333333
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800560      7137       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147713       123.463492063.463492063.463492063.463492063.463492063.463492063
    147715       123.536507937.536507937.536507937.536507937.536507937.536507937
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800561      7146       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147715       123 .06031746 .06031746 .06031746 .06031746 .06031746 .06031746
    147717       123 .93968254 .93968254 .93968254 .93968254 .93968254 .93968254
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800562      7143       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147669       123 .06031746 .06031746 .06031746 .06031746 .06031746 .06031746
    147673       123 .93968254 .93968254 .93968254 .93968254 .93968254 .93968254
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800563      7089       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147637       123.688888889.688888889.688888889.688888889.688888889.688888889
    147641       123.311111111.311111111.311111111.311111111.311111111.311111111
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800564      7086       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147634       123.688888889.688888889.688888889.688888889.688888889.688888889
    147638       123.311111111.311111111.311111111.311111111.311111111.311111111
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800565      7155       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147623       123        .2        .2        .2        .2        .2        .2
    147721       123        .8        .8        .8        .8        .8        .8
$ F0.west.front.opening0.frame.right frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800566      7152       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147610       123        .2        .2        .2        .2        .2        .2
    147681       123        .8        .8        .8        .8        .8        .8
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800567      6888       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85726       123.171428571.171428571.171428571.171428571.171428571.171428571
     85728       123.828571429.828571429.828571429.828571429.828571429.828571429
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800568      6877       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85725       123.171428571.171428571.171428571.171428571.171428571.171428571
     85727       123.828571429.828571429.828571429.828571429.828571429.828571429
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800569      6910       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85725       123.085714286.085714286.085714286.085714286.085714286.085714286
     85727       123.914285714.914285714.914285714.914285714.914285714.914285714
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800570      6921       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85726       123.085714286.085714286.085714286.085714286.085714286.085714286
     85728       123.914285714.914285714.914285714.914285714.914285714.914285714
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800571      6932       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85749       123.085714286.085714286.085714286.085714286.085714286.085714286
     85750       123.914285714.914285714.914285714.914285714.914285714.914285714
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800572      6954       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85728       123         1         1         1         1         1         1
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800573      6965       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85750       123         1         1         1         1         1         1
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800574      6887       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147609       123        .2        .2        .2        .2        .2        .2
    147678       123        .8        .8        .8        .8        .8        .8
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800575      6898       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147610       123        .2        .2        .2        .2        .2        .2
    147681       123        .8        .8        .8        .8        .8        .8
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800576      6931       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147610       123        .6        .6        .6        .6        .6        .6
    147681       123        .4        .4        .4        .4        .4        .4
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800577      6920       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147609       123        .6        .6        .6        .6        .6        .6
    147678       123        .4        .4        .4        .4        .4        .4
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800578      6942       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147623       123        .6        .6        .6        .6        .6        .6
    147721       123        .4        .4        .4        .4        .4        .4
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800579      6975       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147623       123         1         1         1         1         1         1
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800580      6964       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147610       123         1         1         1         1         1         1
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800581      6943       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85727       123         1         1         1         1         1         1
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800582      6944       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85727       123.036144578.036144578.036144578.036144578.036144578.036144578
     85757       123.963855422.963855422.963855422.963855422.963855422.963855422
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800583      6955       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85728       123.036144578.036144578.036144578.036144578.036144578.036144578
     85758       123.963855422.963855422.963855422.963855422.963855422.963855422
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800584      6946       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85820       123.081967213.081967213.081967213.081967213.081967213.081967213
     85841       123.918032787.918032787.918032787.918032787.918032787.918032787
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800585      6947       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85883       123.461538462.461538462.461538462.461538462.461538462.461538462
     85904       123.538461538.538461538.538461538.538461538.538461538.538461538
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800586      6958       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85884       123.461538462.461538462.461538462.461538462.461538462.461538462
     85905       123.538461538.538461538.538461538.538461538.538461538.538461538
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800587      6957       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85821       123.081967213.081967213.081967213.081967213.081967213.081967213
     85842       123.918032787.918032787.918032787.918032787.918032787.918032787
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800588      6949       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147483       123.924137931.924137931.924137931.924137931.924137931.924137931
    147504       123.075862069.075862069.075862069.075862069.075862069.075862069
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800589      6950       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147504       123        .6        .6        .6        .6        .6        .6
    147525       123        .4        .4        .4        .4        .4        .4
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800590      6961       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147505       123        .6        .6        .6        .6        .6        .6
    147526       123        .4        .4        .4        .4        .4        .4
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800591      6960       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147484       123.924137931.924137931.924137931.924137931.924137931.924137931
    147505       123.075862069.075862069.075862069.075862069.075862069.075862069
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800592      6952       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147567       123.986666667.986666667.986666667.986666667.986666667.986666667
    147588       123.013333333.013333333.013333333.013333333.013333333.013333333
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800593      6953       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147609       123         1         1         1         1         1         1
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800594      6963       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147568       123.986666667.986666667.986666667.986666667.986666667.986666667
    147589       123.013333333.013333333.013333333.013333333.013333333.013333333
$ F0.west.front.opening0.frame.top frame_perimeter_anchor
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800595      6974       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147581       123.986666667.986666667.986666667.986666667.986666667.986666667
    147602       123.013333333.013333333.013333333.013333333.013333333.013333333
$ F0.west.front.opening0.frame.top frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800596      6899       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
     85749       123.171428571.171428571.171428571.171428571.171428571.171428571
     85750       123.828571429.828571429.828571429.828571429.828571429.828571429
$ F0.west.front.opening0.frame.top frame_member_joint
*CONSTRAINED_INTERPOLATION
$#    icid      dnid      ddof
   8800597      6909       123
$#    inid      idof    twghtx    twghty    twghtz    rwghtx    rwghty    rwghtz
    147623       123        .2        .2        .2        .2        .2        .2
    147721       123        .8        .8        .8        .8        .8        .8
$ F0.west.front.opening0.leaf0.hinge0.leaf hinge_local_mount
*SET_NODE_LIST
   9200001
      7162      7156      7174      7180    439233    439235
*CONSTRAINED_NODAL_RIGID_BODY
$      PID       CID      NSID     PNODE      IPRT    DRFLAG    RRFLAG
   9100001         0   9200001         0         0         0         0
$ F0.west.front.opening0.leaf0.hinge0.frame hinge_local_mount
*SET_NODE_LIST
   9200002
      6984      6983      6992      6993    439234    439236
*CONSTRAINED_NODAL_RIGID_BODY
$      PID       CID      NSID     PNODE      IPRT    DRFLAG    RRFLAG
   9100002         0   9200002         0         0         0         0
$ F0.west.front.opening0.leaf0.hinge1.leaf hinge_local_mount
*SET_NODE_LIST
   9200003
      7306      7300      7318      7324    439237    439239
*CONSTRAINED_NODAL_RIGID_BODY
$      PID       CID      NSID     PNODE      IPRT    DRFLAG    RRFLAG
   9100003         0   9200003         0         0         0         0
$ F0.west.front.opening0.leaf0.hinge1.frame hinge_local_mount
*SET_NODE_LIST
   9200004
      7056      7055      7064      7065    439238    439240
*CONSTRAINED_NODAL_RIGID_BODY
$      PID       CID      NSID     PNODE      IPRT    DRFLAG    RRFLAG
   9100004         0   9200004         0         0         0         0
$ F0.west.front.opening0.leaf1.hinge0.leaf hinge_local_mount
*SET_NODE_LIST
   9200005
      7342      7336      7354      7360    439241    439243
*CONSTRAINED_NODAL_RIGID_BODY
$      PID       CID      NSID     PNODE      IPRT    DRFLAG    RRFLAG
   9100005         0   9200005         0         0         0         0
$ F0.west.front.opening0.leaf1.hinge0.frame hinge_local_mount
*SET_NODE_LIST
   9200006
      7073      7072      7081      7082    439242    439244
*CONSTRAINED_NODAL_RIGID_BODY
$      PID       CID      NSID     PNODE      IPRT    DRFLAG    RRFLAG
   9100006         0   9200006         0         0         0         0
$ F0.west.front.opening0.leaf1.hinge1.leaf hinge_local_mount
*SET_NODE_LIST
   9200007
      7486      7480      7498      7504    439245    439247
*CONSTRAINED_NODAL_RIGID_BODY
$      PID       CID      NSID     PNODE      IPRT    DRFLAG    RRFLAG
   9100007         0   9200007         0         0         0         0
$ F0.west.front.opening0.leaf1.hinge1.frame hinge_local_mount
*SET_NODE_LIST
   9200008
      7145      7144      7153      7154    439246    439248
*CONSTRAINED_NODAL_RIGID_BODY
$      PID       CID      NSID     PNODE      IPRT    DRFLAG    RRFLAG
   9100008         0   9200008         0         0         0         0
$ F0.flightA.rail8.390.clamp0 railing_ideal_clamp
*SET_NODE_LIST
   9200009
      1700      1703      1704      1701    434803    434793    434794    434804
*CONSTRAINED_NODAL_RIGID_BODY
$      PID       CID      NSID     PNODE      IPRT    DRFLAG    RRFLAG
   9100009         0   9200009         0         0         0         0
$ F0.flightA.rail8.390.clamp1 railing_ideal_clamp
*SET_NODE_LIST
   9200010
      1727      1730      1731      1728    435156    435110    435228    435274
*CONSTRAINED_NODAL_RIGID_BODY
$      PID       CID      NSID     PNODE      IPRT    DRFLAG    RRFLAG
   9100010         0   9200010         0         0         0         0
$ F0.west.balcony_side0.15.trim0.clamp0 railing_ideal_clamp
*SET_NODE_LIST
   9200011
       599       602       603       600     55698     55697     56297     56298
*CONSTRAINED_NODAL_RIGID_BODY
$      PID       CID      NSID     PNODE      IPRT    DRFLAG    RRFLAG
   9100011         0   9200011         0         0         0         0
$ F0.west.balcony_side0.15.trim0.clamp1 railing_ideal_clamp
*SET_NODE_LIST
   9200012
       608       611       612       609     56310     56309     56313     56314
*CONSTRAINED_NODAL_RIGID_BODY
$      PID       CID      NSID     PNODE      IPRT    DRFLAG    RRFLAG
   9100012         0   9200012         0         0         0         0
$ F0.west.front.opening0.leaf0.hinge0
*CONSTRAINED_JOINT_REVOLUTE
$       N1        N2        N3        N4        N5        N6       RPS      DAMP
    439233    439234    439235    439236         0         0         1         0
$ F0.west.front.opening0.leaf0.hinge1
*CONSTRAINED_JOINT_REVOLUTE
$       N1        N2        N3        N4        N5        N6       RPS      DAMP
    439237    439238    439239    439240         0         0         1         0
$ F0.west.front.opening0.leaf1.hinge0
*CONSTRAINED_JOINT_REVOLUTE
$       N1        N2        N3        N4        N5        N6       RPS      DAMP
    439241    439242    439243    439244         0         0         1         0
$ F0.west.front.opening0.leaf1.hinge1
*CONSTRAINED_JOINT_REVOLUTE
$       N1        N2        N3        N4        N5        N6       RPS      DAMP
    439245    439246    439247    439248         0         0         1         0
